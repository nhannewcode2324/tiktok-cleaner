"use strict";
(() => {
  // src/shared/utils.ts
  function normalizeText(input) {
    if (!input) return "";
    return input.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().replace(/\s+/g, " ").trim();
  }
  function parseVideoHref(href) {
    if (!href) return null;
    const m = href.match(/\/@([^/?#]+)\/(video|photo)\/(\d{6,})/);
    if (!m) return null;
    return { author: decodeURIComponent(m[1]), mediaType: m[2], videoId: m[3] };
  }
  function parseCount(text) {
    if (!text) return null;
    const t = text.trim().replace(/\s/g, "").toUpperCase();
    const m = t.match(/^([\d.,]+)([KMB])?$/);
    if (!m) return null;
    let numStr = m[1];
    if (m[2]) numStr = numStr.replace(",", ".");
    else numStr = numStr.replace(/[.,]/g, "");
    const n = parseFloat(numStr);
    if (!Number.isFinite(n)) return null;
    const mult = m[2] === "K" ? 1e3 : m[2] === "M" ? 1e6 : m[2] === "B" ? 1e9 : 1;
    return Math.round(n * mult);
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // src/content/dom-observer.ts
  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const h = el;
    const style = h.ownerDocument.defaultView?.getComputedStyle(h);
    if (style && (style.display === "none" || style.visibility === "hidden" || style.opacity === "0")) return false;
    const r = h.getBoundingClientRect();
    const hasLayout = !(r.width === 0 && r.height === 0 && r.top === 0 && r.left === 0);
    if (!hasLayout) return !isRealBrowserLayout();
    return r.width > 0 && r.height > 0;
  }
  var layoutProbe = null;
  function isRealBrowserLayout() {
    if (layoutProbe !== null) return layoutProbe;
    const body = document.body;
    layoutProbe = !!body && body.getBoundingClientRect().width > 0;
    return layoutProbe;
  }
  function qsa(sel, root = document) {
    return Array.from(root.querySelectorAll(sel));
  }
  function firstVisible(sel, root = document) {
    return qsa(sel, root).find((e) => isVisible(e)) ?? null;
  }
  function clickableAncestor(el) {
    return el.closest('button, [role="button"], [role="menuitem"], [role="tab"], a, [tabindex]') ?? el;
  }
  function hover(el) {
    const opts = { bubbles: true, cancelable: true, view: window };
    el.dispatchEvent(new PointerEvent("pointerover", opts));
    el.dispatchEvent(new MouseEvent("mouseover", opts));
    el.dispatchEvent(new MouseEvent("mouseenter", { ...opts, bubbles: false }));
  }
  function humanClick(el) {
    try {
      el.scrollIntoView({ block: "center", inline: "center" });
    } catch {
    }
    hover(el);
    const opts = { bubbles: true, cancelable: true, view: window, button: 0 };
    el.dispatchEvent(new PointerEvent("pointerdown", opts));
    el.dispatchEvent(new MouseEvent("mousedown", opts));
    el.dispatchEvent(new PointerEvent("pointerup", opts));
    el.dispatchEvent(new MouseEvent("mouseup", opts));
    el.click();
  }
  function pressEscape() {
    const ev = { key: "Escape", code: "Escape", keyCode: 27, bubbles: true };
    document.dispatchEvent(new KeyboardEvent("keydown", ev));
    document.dispatchEvent(new KeyboardEvent("keyup", ev));
  }
  function findByText(patterns, root = document.body, maxLen = 60) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    const doc = root.ownerDocument ?? document;
    const walker = doc.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
      const raw = node.nodeValue ?? "";
      if (!raw.trim() || raw.length > maxLen * 3) continue;
      const parent = node.parentElement;
      if (!parent || seen.has(parent)) continue;
      const t = normalizeText(parent.textContent);
      if (!t || t.length > maxLen) continue;
      const hit = (patterns.exact ?? []).some((p) => t === p) || (patterns.contains ?? []).some((p) => t.includes(p));
      if (hit && isVisible(parent)) {
        seen.add(parent);
        out.push(parent);
      }
    }
    return out;
  }
  var LOGIN_BUTTONS = '[data-e2e="top-login-button"], [data-e2e="nav-login-button"], #header-login-button, #top-right-action-bar-login-button, [data-e2e="login-button"]';
  var LOGGED_IN_HINTS = '[data-e2e="profile-icon"], [data-e2e="inbox-icon"], [data-e2e="nav-profile"], [data-e2e="upload-icon"]';
  var HANDLE_SHAPE = /^[a-z0-9_.]{1,24}$/i;
  function cleanHandle(raw) {
    if (!raw || typeof raw !== "string") return null;
    const h = raw.trim().replace(/^@+/, "").split(/[/?#&]/)[0];
    if (!h || !HANDLE_SHAPE.test(h)) return null;
    if (h.toLowerCase() === "undefined" || h.toLowerCase() === "null") return null;
    return h;
  }
  function usernameFromHref(href) {
    if (!href) return null;
    const m = href.match(/\/@([^/?#]+)/);
    if (!m) return null;
    try {
      return cleanHandle(decodeURIComponent(m[1]));
    } catch {
      return null;
    }
  }
  function detectFromHydration(doc) {
    const el = doc.getElementById("__UNIVERSAL_DATA_FOR_REHYDRATION__");
    if (el && el.textContent) {
      try {
        const data = JSON.parse(el.textContent);
        const defaultScope = data?.["__DEFAULT_SCOPE__"] || data;
        const appContext = defaultScope?.["webapp.app-context"] || defaultScope?.appContext;
        const user = appContext?.user;
        const handle = cleanHandle(user?.uniqueId);
        if (handle) return handle;
      } catch {
      }
    }
    const sigi = doc.getElementById("SIGI_STATE");
    if (sigi && sigi.textContent) {
      try {
        const data = JSON.parse(sigi.textContent);
        const uniqueId = cleanHandle(
          data?.AppContext?.appContext?.user?.uniqueId || data?.AppContext?.user?.uniqueId
        );
        if (uniqueId) return uniqueId;
      } catch {
      }
    }
    return null;
  }
  function detectFromScripts(doc) {
    const scripts = qsa("script", doc);
    for (const s of scripts) {
      if (s.id === "__UNIVERSAL_DATA_FOR_REHYDRATION__" || s.id === "SIGI_STATE") continue;
      const text = s.textContent || "";
      if (text.includes("appContext") && text.includes("uniqueId")) {
        const m = text.match(/"appContext"\s*:\s*\{[^{}]*"user"\s*:\s*\{[^{}]*"uniqueId"\s*:\s*"([a-zA-Z0-9_.]{1,24})"/);
        const handle = cleanHandle(m?.[1]);
        if (handle) return handle;
      }
    }
    return null;
  }
  function detectAccount(doc = document) {
    const fromHydration = detectFromHydration(doc);
    if (fromHydration) {
      return { loggedIn: true, username: fromHydration, source: "nav" };
    }
    const fromScripts = detectFromScripts(doc);
    if (fromScripts) {
      return { loggedIn: true, username: fromScripts, source: "nav" };
    }
    const navLinks = qsa(
      'a[data-e2e="nav-profile"], [data-e2e="nav-profile"] a, a[data-e2e="profile-icon"], [data-e2e="profile-icon"] a, nav a[href*="/@"], header a[href*="/@"], [data-e2e*="sidebar"] a[href*="/@"]',
      doc
    );
    for (const a of navLinks) {
      if (a.closest('main, [data-e2e*="recommend"], [data-e2e*="suggest"], [data-e2e*="following"]')) continue;
      const href = a.getAttribute("href");
      if (href && !href.includes("/video/") && !href.includes("/photo/") && !href.includes("/music/") && !href.includes("/tag/")) {
        const u = usernameFromHref(href);
        if (u) return { loggedIn: true, username: u, source: "nav" };
      }
    }
    if (isOwnProfile(doc)) {
      const u = usernameFromHref(doc.location?.pathname);
      if (u) return { loggedIn: true, username: u, source: "profile" };
    }
    const loginBtn = qsa(LOGIN_BUTTONS, doc).some((e) => isVisible(e));
    if (loginBtn) return { loggedIn: false, username: null, source: "none" };
    const hints = doc.querySelector(LOGGED_IN_HINTS);
    return { loggedIn: !!hints, username: null, source: "none" };
  }
  function isOwnProfile(doc = document) {
    if (doc.querySelector('[data-e2e="edit-profile-entrance"], [data-e2e="edit-profile-button"]')) return true;
    const texts = ["edit profile", "sua ho so", "chinh sua ho so"];
    return qsa('button, [role="button"]', doc).some((b) => texts.includes(normalizeText(b.textContent)));
  }
  var CAPTCHA_SELECTORS = [
    "#captcha-verify-container-main-page",
    "#captcha_container",
    ".captcha_verify_container",
    ".captcha-verify-container",
    '[class*="captcha_verify"]',
    '[class*="CaptchaVerify"]',
    'iframe[src*="captcha"]',
    '[id*="captcha"][role="dialog"]'
  ].join(",");
  var CAPTCHA_TEXT = ["drag the slider", "verify to continue", "keo thanh truot", "xac minh de tiep tuc", "select 2 objects"];
  function detectCaptcha(doc = document) {
    if (qsa(CAPTCHA_SELECTORS, doc).some((e) => isVisible(e))) return true;
    const dialogs = qsa('[role="dialog"], [class*="modal" i]', doc).filter((d) => isVisible(d));
    return dialogs.some((d) => {
      const t = normalizeText(d.textContent).slice(0, 400);
      return CAPTCHA_TEXT.some((p) => t.includes(p));
    });
  }
  var RATE_LIMIT_TEXT = [
    "tapping too fast",
    "too many requests",
    "too many attempts",
    "try again later",
    "action blocked",
    "thao tac qua nhanh",
    "qua nhieu lan",
    "thu lai sau",
    "qua nhieu yeu cau"
  ];
  function toastTexts(doc = document) {
    return qsa('[role="alert"], [role="status"], [class*="toast" i], [class*="Toast"], [data-e2e*="toast"]', doc).filter((e) => isVisible(e)).map((e) => normalizeText(e.textContent)).filter(Boolean);
  }
  function detectRateLimit(doc = document) {
    return toastTexts(doc).some((t) => RATE_LIMIT_TEXT.some((p) => t.includes(p)));
  }
  var UNAVAILABLE_TEXT = [
    "video currently unavailable",
    "this video is unavailable",
    "video is unavailable",
    "post is unavailable",
    "video has been removed",
    "this video is private",
    "couldn't find this video",
    "couldnt find this video",
    "video hien khong kha dung",
    "video nay khong kha dung",
    "khong the xem video",
    "video da bi xoa",
    "bai dang khong kha dung"
  ];
  function detectUnavailable(doc = document) {
    const main = doc.querySelector("main, #main-content-video_detail, #app") ?? doc.body;
    const t = normalizeText(main?.textContent).slice(0, 2e4);
    return UNAVAILABLE_TEXT.some((p) => t.includes(p));
  }
  function detectOffline() {
    return typeof navigator !== "undefined" && navigator.onLine === false;
  }
  function detectHttp403(doc = document) {
    const title = (doc.title || "").toLowerCase();
    if (title.includes("403 forbidden") || title.includes("access denied")) return true;
    const bodyText = (doc.body?.textContent || "").toLowerCase();
    if (bodyText.includes("http error 403") || bodyText.includes("access to www.tiktok.com was denied") || bodyText.includes("you don't have authorization to view this page") || bodyText.includes("403 forbidden")) {
      return true;
    }
    return false;
  }

  // src/services/video-scanner.ts
  var GRID_SELECTORS = {
    repost: [
      '[data-e2e="user-repost-item-list"]',
      '[data-e2e*="repost-item-list"]',
      '[data-e2e*="repost-list"]',
      'div[data-e2e*="repost"] [data-e2e*="item-list"]'
    ],
    like: [
      '[data-e2e="user-liked-item-list"]',
      '[data-e2e*="liked-item-list"]',
      '[data-e2e*="like-list"]',
      'div[data-e2e*="liked"] [data-e2e*="item-list"]'
    ]
  };
  function detectItemUnavailable(container) {
    const text = (container.textContent || "").toLowerCase();
    const unavailPatterns = [
      "unavailable",
      "kh\xF4ng kh\u1EA3 d\u1EE5ng",
      "khong kha dung",
      "has been removed",
      "\u0111\xE3 b\u1ECB x\xF3a",
      "da bi xoa",
      "this video is private",
      "video n\xE0y l\xE0 ri\xEAng t\u01B0",
      "ri\xEAng t\u01B0",
      "rieng tu",
      "b\u1ECB \u1EA9n",
      "bi an"
    ];
    if (unavailPatterns.some((p) => text.includes(p))) return true;
    if (container.querySelector('[data-e2e*="unavailable"], [class*="unavailable" i], [class*="private" i], [class*="deleted" i]')) {
      return true;
    }
    return false;
  }
  var ITEM_CONTAINER = '[data-e2e="user-post-item"], [data-e2e="user-liked-item"], [data-e2e="user-repost-item"], [data-e2e$="-item"]';
  var EXCLUDE_ANCESTORS = 'header, nav, aside, [data-e2e="recommend-list"], [data-e2e*="comment"]';
  function isUsableUrl(u) {
    if (!u) return false;
    const s = u.trim();
    return /^https?:\/\//i.test(s) && !/^data:/i.test(s);
  }
  function firstFromSrcset(srcset) {
    if (!srcset) return null;
    const first = srcset.split(",")[0]?.trim().split(/\s+/)[0];
    return isUsableUrl(first) ? first : null;
  }
  function pickThumbnail(container) {
    const imgs = Array.from(container.querySelectorAll("img"));
    for (const img of imgs) {
      const cands = [
        img.currentSrc,
        img.getAttribute("src"),
        img.getAttribute("data-src"),
        firstFromSrcset(img.getAttribute("srcset"))
      ];
      for (const c of cands) if (isUsableUrl(c)) return c.trim();
    }
    const source = container.querySelector("picture source[srcset]");
    const fromSource = firstFromSrcset(source?.getAttribute("srcset"));
    if (fromSource) return fromSource;
    const withBg = Array.from(container.querySelectorAll('[style*="background-image"]'));
    for (const el of withBg) {
      const m = el.getAttribute("style")?.match(/background-image:\s*url\((['"]?)(.*?)\1\)/i);
      if (m && isUsableUrl(m[2])) return m[2];
    }
    return null;
  }
  function cleanDescription(text) {
    if (!text) return "";
    let t = text.replace(/\s+/g, " ").trim();
    t = t.replace(/\s+created by .+? with .+$/i, "").trim();
    return t.length > 300 ? t.slice(0, 297) + "\u2026" : t;
  }
  function findGrid(root, kind) {
    for (const sel of GRID_SELECTORS[kind]) {
      const el = root.querySelector(sel);
      if (el) return el;
    }
    const panel = root.querySelector(`[role="tabpanel"][data-e2e*="${kind}" i], [role="tabpanel"][aria-labelledby*="${kind}" i], [role="tabpanel"][id*="${kind}" i]`);
    if (panel) return panel;
    const activeTab = root.querySelector(`[role="tab"][aria-selected="true"], [data-e2e*="${kind}-tab"][aria-selected="true"], [data-e2e*="${kind}-tab"].active, [data-active="true"]`);
    if (activeTab) {
      const tabText = (activeTab.textContent || activeTab.getAttribute("data-e2e") || "").toLowerCase();
      const isTargetTab = kind === "repost" ? /repost|dang lai|đăng lại/i.test(tabText) : /liked|da thich|đã thích/i.test(tabText) && !/yeu thich|yêu thích|favorite/i.test(tabText);
      if (isTargetTab) {
        const oppositeE2e = kind === "repost" ? "user-liked-item-list" : "user-repost-item-list";
        const lists = Array.from(root.querySelectorAll('[data-e2e*="item-list"]'));
        for (const el of lists) {
          const e2e = (el.getAttribute("data-e2e") || "").toLowerCase();
          if (e2e === "user-post-item-list" || e2e === oppositeE2e) continue;
          return el;
        }
        const panels = Array.from(root.querySelectorAll('[role="tabpanel"]'));
        for (const panelEl of panels) {
          if (panelEl.querySelector('[data-e2e="user-post-item-list"]')) continue;
          if (panelEl.querySelector(`[data-e2e="${oppositeE2e}"]`)) continue;
          return panelEl;
        }
      }
    }
    return null;
  }
  function findVideoAnchors(scope) {
    const anchors = Array.from(scope.querySelectorAll('a[href*="/video/"], a[href*="/photo/"]'));
    return anchors.filter((a) => !a.closest(EXCLUDE_ANCESTORS) && parseVideoHref(a.getAttribute("href")));
  }
  function extractItem(anchor, kind, origin = "https://www.tiktok.com", loggedInUser) {
    const href = anchor.getAttribute("href");
    const parsed = parseVideoHref(href);
    if (!parsed) return null;
    if (kind === "repost" && anchor.closest('[data-e2e="user-liked-item-list"]')) {
      return null;
    }
    if (kind === "like" && anchor.closest('[data-e2e="user-repost-item-list"]')) {
      return null;
    }
    if (loggedInUser) {
      try {
        const cleanUser = decodeURIComponent(loggedInUser).replace(/^@/, "").toLowerCase().trim();
        const cleanAuthor = decodeURIComponent(parsed.author || "").replace(/^@/, "").toLowerCase().trim();
        if (cleanUser && cleanAuthor === cleanUser) {
          return null;
        }
      } catch {
        const cleanUser = loggedInUser.replace(/^@/, "").toLowerCase().trim();
        const cleanAuthor = (parsed.author || "").replace(/^@/, "").toLowerCase().trim();
        if (cleanUser && cleanAuthor === cleanUser) {
          return null;
        }
      }
    }
    const container = anchor.closest(ITEM_CONTAINER) ?? anchor.parentElement ?? anchor;
    const isPrivateLock = !!container.querySelector('[data-e2e*="private"], [data-e2e*="lock"], [aria-label*="ri\xEAng t\u01B0" i], [aria-label*="private" i], [class*="lock" i]');
    if (isPrivateLock && loggedInUser) {
      try {
        const cleanUser = decodeURIComponent(loggedInUser).replace(/^@/, "").toLowerCase().trim();
        const cleanAuthor = decodeURIComponent(parsed.author || "").replace(/^@/, "").toLowerCase().trim();
        if (cleanUser && cleanAuthor === cleanUser) {
          return null;
        }
      } catch {
      }
    }
    const img = container.querySelector("img");
    const descEl = container.querySelector('[data-e2e*="desc"]');
    const viewsEl = container.querySelector('[data-e2e="video-views"]');
    const viewsText = viewsEl?.textContent?.trim() || null;
    let url;
    try {
      const u = new URL(href, origin);
      url = `${u.origin}${u.pathname}`;
    } catch {
      url = `${origin}/@${parsed.author}/${parsed.mediaType}/${parsed.videoId}`;
    }
    const isUnavailable = detectItemUnavailable(container);
    return {
      videoId: parsed.videoId,
      kind,
      mediaType: parsed.mediaType,
      url,
      author: parsed.author,
      description: cleanDescription(img?.getAttribute("alt") || anchor.getAttribute("title") || descEl?.textContent || ""),
      thumbnail: pickThumbnail(container),
      viewsText,
      views: parseCount(viewsText),
      isUnavailable
    };
  }
  function extractAll(scope, kind, origin, loggedInUser) {
    const map = /* @__PURE__ */ new Map();
    for (const a of findVideoAnchors(scope)) {
      const item = extractItem(a, kind, origin, loggedInUser);
      if (!item) continue;
      const prev = map.get(item.videoId);
      if (!prev) map.set(item.videoId, item);
      else map.set(item.videoId, mergeItem(prev, item));
    }
    return [...map.values()];
  }
  function mergeItem(prev, next) {
    return {
      ...prev,
      thumbnail: next.thumbnail || prev.thumbnail,
      description: prev.description || next.description,
      viewsText: next.viewsText ?? prev.viewsText,
      views: next.views ?? prev.views,
      isUnavailable: next.isUnavailable || prev.isUnavailable
    };
  }

  // src/content/abort-signal.ts
  var scanController = new AbortController();
  var actionController = new AbortController();
  function resetScanAbort() {
    scanController = new AbortController();
    return scanController.signal;
  }
  function abortScan() {
    if (!scanController.signal.aborted) {
      scanController.abort();
    }
  }
  function isScanAborted() {
    return scanController.signal.aborted;
  }
  function getScanAbortSignal() {
    return scanController.signal;
  }
  function resetActionAbort() {
    actionController = new AbortController();
    return actionController.signal;
  }
  function abortAction() {
    if (!actionController.signal.aborted) {
      actionController.abort();
    }
  }
  function isActionAborted() {
    return actionController.signal.aborted;
  }
  function getActionAbortSignal() {
    return actionController.signal;
  }
  function sleepWithAbort(ms, signal) {
    if (signal.aborted) return Promise.resolve(false);
    if (ms <= 0) return Promise.resolve(true);
    return new Promise((resolve) => {
      let settled = false;
      const onAbort = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(false);
      };
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        signal.removeEventListener("abort", onAbort);
        resolve(true);
      }, ms);
      signal.addEventListener("abort", onAbort, { once: true });
    });
  }
  function sleepUnlessScanAborted(ms) {
    return sleepWithAbort(ms, scanController.signal);
  }
  function sleepUnlessActionAborted(ms) {
    return sleepWithAbort(ms, actionController.signal);
  }

  // src/content/tiktok-api.ts
  var UserAbortError = class extends Error {
    constructor(message = "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.") {
      super(message);
      this.name = "UserAbortError";
    }
  };
  var SafetyStopError = class extends Error {
    constructor(code, message) {
      super(message);
      this.code = code;
      this.name = "SafetyStopError";
    }
  };
  var TransientError = class extends Error {
    constructor(message) {
      super(message);
      this.name = "TransientError";
    }
  };
  var HttpError = class extends Error {
    constructor(status, message) {
      super(message || `TikTok request failed (${status}).`);
      this.status = status;
      this.name = "HttpError";
    }
  };
  var SAFETY_MESSAGE = /captcha|verify|verification|too many|too frequent|rate.?limit|risk|restricted|unusual|slow down|thao tác quá nhanh|quá nhiều lần|xác minh/i;
  var REQUEST_TIMEOUT_MS = 2e4;
  var REQUESTED_PAGE_SIZE = 50;
  var FALLBACK_PAGE_SIZE = 30;
  var repostPageSize = REQUESTED_PAGE_SIZE;
  function randomBetween(min, max) {
    return Math.floor(min + Math.random() * (max - min + 1));
  }
  async function waitWhile(ms, shouldContinue) {
    const end = Date.now() + ms;
    while (shouldContinue() && Date.now() < end) {
      const step = Math.min(250, end - Date.now());
      if (step > 0) {
        await new Promise((resolve) => setTimeout(resolve, step));
      }
    }
    return shouldContinue();
  }
  function formatCompactCount(count) {
    if (typeof count !== "number" || !Number.isFinite(count) || count < 0) return null;
    if (count >= 1e9) return `${(count / 1e9).toFixed(1).replace(/\.0$/, "")}B`;
    if (count >= 1e6) return `${(count / 1e6).toFixed(1).replace(/\.0$/, "")}M`;
    if (count >= 1e3) return `${(count / 1e3).toFixed(1).replace(/\.0$/, "")}K`;
    return String(count);
  }
  async function executeTikTokFetch(pathAndQuery, method = "GET", body, headers, abortSignal) {
    if (abortSignal?.aborted) {
      throw new UserAbortError();
    }
    const raceWithAbort = (promise) => {
      if (!abortSignal) return promise;
      if (abortSignal.aborted) return Promise.reject(new UserAbortError());
      return new Promise((resolve, reject) => {
        const onAbort = () => reject(new UserAbortError());
        abortSignal.addEventListener("abort", onAbort, { once: true });
        promise.then(
          (val) => {
            abortSignal.removeEventListener("abort", onAbort);
            resolve(val);
          },
          (err) => {
            abortSignal.removeEventListener("abort", onAbort);
            reject(err);
          }
        );
      });
    };
    try {
      const res = await raceWithAbort(
        chrome.runtime.sendMessage({
          type: "TIKTOK_API_FETCH",
          pathAndQuery,
          method,
          body,
          headers,
          timeoutMs: REQUEST_TIMEOUT_MS
        })
      );
      if (res && typeof res.status === "number") {
        return res;
      }
    } catch (err) {
      if (err instanceof UserAbortError) throw err;
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    const onExternalAbort = () => controller.abort();
    abortSignal?.addEventListener("abort", onExternalAbort, { once: true });
    try {
      const url = pathAndQuery.startsWith("http") ? pathAndQuery : `${window.location.origin}${pathAndQuery.startsWith("/") ? "" : "/"}${pathAndQuery}`;
      const response = await fetch(url, {
        method,
        headers,
        body,
        credentials: "include",
        signal: controller.signal
      });
      const text = await response.text();
      let data = null;
      if (text) {
        try {
          data = JSON.parse(text);
        } catch {
          data = null;
        }
      }
      return {
        ok: response.ok,
        status: response.status,
        data
      };
    } catch (err) {
      if (abortSignal?.aborted) {
        throw new UserAbortError();
      }
      const timedOut = err instanceof DOMException && err.name === "AbortError";
      return {
        ok: false,
        status: 0,
        data: null,
        timedOut,
        networkError: err instanceof Error ? err.message : String(err)
      };
    } finally {
      clearTimeout(timer);
      abortSignal?.removeEventListener("abort", onExternalAbort);
    }
  }
  async function requestTikTokJson(pathAndQuery, options) {
    const method = options?.method ?? "GET";
    const retries = method === "GET" ? options?.retries ?? 2 : 0;
    let lastError;
    for (let attempt = 0; attempt <= retries; attempt += 1) {
      if (options?.signal?.aborted) {
        throw new UserAbortError();
      }
      if (detectHttp403(document)) {
        throw new SafetyStopError(
          "HTTP_403",
          "TikTok t\u1EEB ch\u1ED1i truy c\u1EADp (HTTP 403). \u0110\xE3 d\u1EEBng an to\xE0n v\xE0 l\u01B0u ti\u1EBFn \u0111\u1ED9."
        );
      }
      if (detectCaptcha(document)) {
        throw new SafetyStopError(
          "CAPTCHA",
          "Ph\xE1t hi\u1EC7n x\xE1c minh CAPTCHA tr\xEAn TikTok. Vui l\xF2ng ho\xE0n t\u1EA5t x\xE1c minh tr\u01B0\u1EDBc khi ti\u1EBFp t\u1EE5c."
        );
      }
      const res = await executeTikTokFetch(
        pathAndQuery,
        method,
        options?.body,
        options?.headers,
        options?.signal
      );
      if (res.status === 401 || res.status === 403 || res.status === 429) {
        const code = res.status === 403 ? "HTTP_403" : res.status === 429 ? "RATE_LIMIT" : "HTTP_401";
        throw new SafetyStopError(
          code,
          `TikTok tr\u1EA3 v\u1EC1 m\xE3 ${res.status}. \u0110\xE3 d\u1EEBng ngay \u0111\u1EC3 b\u1EA3o v\u1EC7 t\xE0i kho\u1EA3n v\xE0 l\u01B0u to\xE0n b\u1ED9 ti\u1EBFn \u0111\u1ED9.`
        );
      }
      try {
        if (res.timedOut) {
          throw new TransientError("Y\xEAu c\u1EA7u t\u1EDBi TikTok qu\xE1 th\u1EDDi gian ch\u1EDD (20 gi\xE2y).");
        }
        if (res.networkError) {
          throw new TransientError(`L\u1ED7i m\u1EA1ng khi k\u1EBFt n\u1ED1i TikTok: ${res.networkError}`);
        }
        if (res.status >= 500) {
          throw new TransientError(`M\xE1y ch\u1EE7 TikTok t\u1EA1m th\u1EDDi b\u1EADn (${res.status}).`);
        }
        if (!res.ok) {
          throw new HttpError(res.status);
        }
        if (res.data === null || typeof res.data !== "object") {
          throw new Error("EMPTY_JSON_BODY");
        }
        return res.data;
      } catch (error) {
        if (error instanceof UserAbortError || options?.signal?.aborted) {
          throw new UserAbortError();
        }
        lastError = error;
        const isTransient = error instanceof TransientError;
        if (error instanceof SafetyStopError || !isTransient || attempt === retries) {
          throw lastError;
        }
        const delayMs = 500 * 2 ** attempt;
        await new Promise((resolve) => setTimeout(resolve, delayMs));
      }
    }
    throw lastError;
  }
  function assertTikTokSuccess(result, actionLabel) {
    const code = result.status_code ?? result.statusCode ?? 0;
    if (code === 0) return;
    const msg = result.status_msg || result.statusMsg || `TikTok kh\xF4ng th\u1EC3 ${actionLabel} (m\xE3 ${code}).`;
    if (SAFETY_MESSAGE.test(msg)) {
      throw new SafetyStopError("SAFETY_STOP", `${msg} \u2014 \u0110\xE3 d\u1EEBng an to\xE0n \u0111\u1EC3 b\u1EA3o v\u1EC7 t\xE0i kho\u1EA3n.`);
    }
    throw new Error(msg);
  }
  async function fetchPageSession() {
    try {
      const res = await chrome.runtime.sendMessage({
        type: "GET_PAGE_SESSION"
      });
      if (res) return res;
    } catch {
    }
    return {
      loggedIn: false,
      username: null,
      secUid: null,
      uid: null,
      http403: detectHttp403(document)
    };
  }
  function mapApiItemToVideo(item, kind, loggedInUsername, scanPage) {
    if (!item.id) return null;
    const author = (item.author?.uniqueId || "").trim();
    const cleanUser = loggedInUsername.replace(/^@/, "").toLowerCase().trim();
    const cleanAuthor = author.replace(/^@/, "").toLowerCase().trim();
    if (cleanUser && cleanAuthor && cleanAuthor === cleanUser) {
      return null;
    }
    if ((item.privateItem || item.secret) && cleanAuthor === cleanUser) {
      return null;
    }
    const mediaType = item.imagePost ? "photo" : "video";
    const thumbnail = item.video?.cover || item.video?.originCover || item.video?.dynamicCover || item.imagePost?.images?.[0]?.imageURL?.urlList?.[0] || null;
    const isUnavailable = Boolean(
      item.status?.isDelete || item.status?.isPrivate || typeof item.takeDown === "number" && item.takeDown > 0 || !thumbnail && !item.video?.playAddr && !item.imagePost
    );
    const safeAuthor = author || "unknown";
    const playCount = item.stats?.playCount ?? null;
    const createTime = typeof item.createTime === "number" && Number.isFinite(item.createTime) && item.createTime > 0 ? item.createTime : null;
    return {
      videoId: String(item.id),
      kind,
      mediaType,
      url: `https://www.tiktok.com/@${safeAuthor}/${mediaType}/${item.id}`,
      author: safeAuthor,
      description: (item.desc || "").trim().slice(0, 300),
      thumbnail,
      views: typeof playCount === "number" ? playCount : null,
      viewsText: formatCompactCount(playCount),
      isUnavailable,
      createTime,
      scanPage
    };
  }
  async function listApiPage(kind, secUid, loggedInUsername, cursor, scanPage, signal) {
    if (kind === "repost") {
      const requestRepostPage = (count) => {
        const params2 = new URLSearchParams({
          aid: "1988",
          count: String(count),
          coverFormat: "2",
          cursor,
          needPinnedItemIds: "true",
          post_item_list_request_type: "0",
          secUid
        });
        return requestTikTokJson(`/api/repost/item_list/?${params2.toString()}`, {
          method: "GET",
          retries: 2,
          signal
        });
      };
      let result2;
      try {
        result2 = await requestRepostPage(repostPageSize);
      } catch (err) {
        if (err instanceof HttpError && err.status === 400 && repostPageSize === REQUESTED_PAGE_SIZE) {
          repostPageSize = FALLBACK_PAGE_SIZE;
          result2 = await requestRepostPage(repostPageSize);
        } else {
          throw err;
        }
      }
      assertTikTokSuccess(result2, "t\u1EA3i danh s\xE1ch Repost");
      const rawItems2 = Array.isArray(result2.itemList) ? result2.itemList : [];
      const items2 = rawItems2.map((it) => mapApiItemToVideo(it, "repost", loggedInUsername, scanPage)).filter((it) => it !== null);
      const nextCursor2 = result2.cursor == null ? cursor : String(result2.cursor);
      return {
        items: items2,
        returned: rawItems2.length,
        hasMore: Boolean(result2.hasMore),
        cursor: nextCursor2
      };
    }
    const params = new URLSearchParams({
      aid: "1988",
      count: "30",
      coverFormat: "2",
      cursor,
      secUid
    });
    const result = await requestTikTokJson(`/api/favorite/item_list/?${params.toString()}`, {
      method: "GET",
      retries: 2,
      signal
    });
    assertTikTokSuccess(result, "t\u1EA3i danh s\xE1ch \u0110\xE3 th\xEDch");
    const rawItems = Array.isArray(result.itemList) ? result.itemList : [];
    const items = rawItems.map((it) => mapApiItemToVideo(it, "like", loggedInUsername, scanPage)).filter((it) => it !== null);
    const nextCursor = result.cursor == null ? cursor : String(result.cursor);
    return {
      items,
      returned: rawItems.length,
      hasMore: Boolean(result.hasMore),
      cursor: nextCursor
    };
  }
  async function scanKindViaApi(kind, secUid, username, limit, knownIds, isAborted) {
    const seenIds = new Set(knownIds);
    const visitedCursors = /* @__PURE__ */ new Set();
    let cursor = "0";
    let pagesScanned = 0;
    let totalFound = 0;
    const kindLabel = kind === "repost" ? "Repost" : "\u0110\xE3 th\xEDch";
    const scanSignal = getScanAbortSignal();
    while (!isAborted() && !scanSignal.aborted && totalFound < limit) {
      if (visitedCursors.has(cursor)) {
        break;
      }
      visitedCursors.add(cursor);
      let page;
      try {
        page = await listApiPage(kind, secUid, username, cursor, pagesScanned + 1, scanSignal);
      } catch (err) {
        if (err instanceof UserAbortError || isAborted() || scanSignal.aborted) {
          break;
        }
        if (err instanceof SafetyStopError) {
          return {
            ok: false,
            code: err.code,
            message: err.message,
            total: totalFound,
            pagesScanned,
            haltRun: true
          };
        }
        if (pagesScanned === 0) {
          return {
            ok: false,
            code: "API_FALLBACK_DOM",
            message: err instanceof Error ? err.message : String(err),
            total: 0,
            pagesScanned: 0,
            fallbackToDom: true
          };
        }
        return {
          ok: true,
          code: "PARTIAL_SAVED",
          message: `\u0110\xE3 l\u01B0u ${totalFound} video ${kindLabel} (${pagesScanned} trang) tr\u01B0\u1EDBc khi k\u1EBFt n\u1ED1i gi\xE1n \u0111o\u1EA1n.`,
          total: totalFound,
          pagesScanned
        };
      }
      if (isAborted() || scanSignal.aborted) {
        break;
      }
      pagesScanned += 1;
      const newItems = page.items.filter((it) => !seenIds.has(it.videoId));
      if (newItems.length > 0) {
        const remainingQuota = Math.max(0, limit - totalFound);
        const batch = newItems.slice(0, remainingQuota);
        for (const it of batch) {
          seenIds.add(it.videoId);
        }
        totalFound += batch.length;
        await chrome.runtime.sendMessage({
          type: "SCAN_BATCH",
          kind,
          items: batch
        }).catch(() => {
        });
      }
      if (isAborted() || scanSignal.aborted) {
        break;
      }
      await chrome.runtime.sendMessage({
        type: "SCAN_PROGRESS",
        kind,
        found: totalFound,
        message: page.hasMore ? `\u0110ang qu\xE9t ${kindLabel}: ${totalFound} video (trang ${pagesScanned})...` : `\u0110\xE3 qu\xE9t h\u1EBFt ${kindLabel}: ${totalFound} video (${pagesScanned} trang).`
      }).catch(() => {
      });
      if (!page.hasMore) {
        break;
      }
      if (totalFound >= limit) {
        break;
      }
      if (!page.cursor || page.cursor === cursor || page.cursor === "0" || page.cursor === "-1") {
        break;
      }
      if (page.returned === 0) {
        break;
      }
      cursor = page.cursor;
      const cooldownMs = randomBetween(1800, 3500);
      const keepGoing = !isAborted() && !scanSignal.aborted && await sleepWithAbort(cooldownMs, scanSignal) && !isAborted();
      if (!keepGoing) break;
    }
    if (isAborted() || scanSignal.aborted) {
      return {
        ok: true,
        code: "CANCELLED",
        message: `\u0110\xE3 d\u1EEBng qu\xE9t; \u0111\xE3 l\u01B0u ${totalFound} video ${kindLabel}.`,
        total: totalFound,
        pagesScanned
      };
    }
    if (kind === "like" && totalFound === 0) {
      return {
        ok: false,
        code: "API_LIKE_EMPTY_VERIFY_DOM",
        message: "\u0110ang ki\u1EC3m tra danh s\xE1ch \u0110\xE3 th\xEDch tr\xEAn giao di\u1EC7n...",
        total: 0,
        pagesScanned,
        fallbackToDom: true
      };
    }
    return {
      ok: true,
      code: totalFound === 0 ? "EMPTY" : totalFound >= limit ? "LIMIT_REACHED" : "COMPLETED",
      message: totalFound === 0 ? `Kh\xF4ng c\xF3 video ${kindLabel} n\xE0o.` : `Qu\xE9t th\xE0nh c\xF4ng! \u0110\xE3 t\xECm th\u1EA5y ${totalFound} video ${kindLabel} (${pagesScanned} trang).`,
      total: totalFound,
      pagesScanned
    };
  }
  async function deleteRepostViaApi(videoId) {
    const actionSignal = getActionAbortSignal();
    if (actionSignal.aborted) {
      throw new UserAbortError();
    }
    const params = new URLSearchParams({
      aid: "1988",
      item_id: videoId
    });
    const result = await requestTikTokJson(
      `/tiktok/v1/upvote/delete?${params.toString()}`,
      {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: "",
        retries: 0,
        signal: actionSignal
      }
    );
    assertTikTokSuccess(result, "x\xF3a \u0111\u0103ng l\u1EA1i");
  }
  async function verifyRepostsViaApi(secUid, username, pageLimit, isAborted) {
    const presentIds = [];
    const visited = /* @__PURE__ */ new Set();
    let cursor = "0";
    let page = 0;
    const maxPages = Math.max(1, Math.min(pageLimit, 50));
    const actionSignal = getActionAbortSignal();
    const checkAborted = () => Boolean(isAborted?.() || actionSignal.aborted);
    while (page < maxPages && !checkAborted()) {
      if (visited.has(cursor)) break;
      visited.add(cursor);
      let res;
      try {
        res = await listApiPage("repost", secUid, username, cursor, page + 1, actionSignal);
      } catch (err) {
        if (err instanceof UserAbortError || checkAborted()) {
          return { ok: false, presentIds };
        }
        throw err;
      }
      page += 1;
      for (const it of res.items) {
        presentIds.push(it.videoId);
      }
      if (!res.hasMore || page >= maxPages || !res.cursor || res.cursor === cursor) {
        break;
      }
      cursor = res.cursor;
      const cont = await waitWhile(randomBetween(1800, 3200), () => !checkAborted());
      if (!cont) break;
    }
    return { ok: !checkAborted(), presentIds };
  }

  // src/content/scanner.ts
  function stopScanning() {
    abortScan();
  }
  var TAB_TEXT_PATTERNS = {
    repost: {
      contains: ["repost", "dang lai", "\u0111\u0103ng l\u1EA1i", "da dang lai", "\u0111\xE3 \u0111\u0103ng l\u1EA1i", "b\xE0i \u0111\u0103ng l\u1EA1i", "bai dang lai"],
      exclude: []
    },
    like: {
      contains: ["da thich", "\u0111\xE3 th\xEDch", "liked", "video \u0111\xE3 th\xEDch"],
      exclude: ["yeu thich", "y\xEAu th\xEDch", "favorite", "favorites"]
    }
  };
  function findProfileTabButton(kind, doc = document) {
    const selectors = kind === "repost" ? [
      '[data-e2e="user-repost-tab"]',
      '[data-e2e="repost-tab"]',
      '[data-e2e*="repost-tab"]',
      '[data-e2e*="repost"]',
      '[role="tab"][aria-controls*="repost"]',
      '[role="tab"][id*="repost"]'
    ] : [
      '[data-e2e="user-liked-tab"]',
      '[data-e2e="liked-tab"]',
      '[data-e2e*="liked-tab"]',
      '[data-e2e*="liked"]',
      '[role="tab"][aria-controls*="liked"]',
      '[role="tab"][id*="liked"]'
    ];
    for (const sel of selectors) {
      const el = firstVisible(sel, doc);
      if (el) {
        const text = (el.textContent || "").toLowerCase();
        if (kind === "like" && (text.includes("y\xEAu th\xEDch") || text.includes("yeu thich") || text.includes("favorite"))) {
          continue;
        }
        return clickableAncestor(el);
      }
    }
    const tabContainers = qsa('[data-e2e="user-tab-list"], [role="tablist"], div[class*="TabContainer"], div[class*="tab-container"]', doc);
    const searchRoots = tabContainers.length > 0 ? tabContainers : [doc.body];
    for (const root of searchRoots) {
      const matches = findByText(TAB_TEXT_PATTERNS[kind], root);
      for (const m of matches) {
        const text = (m.textContent || "").toLowerCase();
        if (TAB_TEXT_PATTERNS[kind].exclude.some((ex) => text.includes(ex))) {
          continue;
        }
        const ancestor = clickableAncestor(m);
        if (isVisible(ancestor)) {
          return ancestor;
        }
      }
    }
    const allMatches = findByText(TAB_TEXT_PATTERNS[kind], doc.body);
    for (const m of allMatches) {
      const text = (m.textContent || "").toLowerCase();
      if (TAB_TEXT_PATTERNS[kind].exclude.some((ex) => text.includes(ex))) {
        continue;
      }
      const ancestor = clickableAncestor(m);
      if (isVisible(ancestor)) {
        return ancestor;
      }
    }
    return null;
  }
  function isTabActive(btn) {
    if (btn.getAttribute("aria-selected") === "true") return true;
    if (btn.getAttribute("data-active") === "true") return true;
    const cls = (btn.className || "").toLowerCase();
    if (cls.includes("active") || cls.includes("selected") || cls.includes("underline")) return true;
    const parent = btn.parentElement;
    if (parent) {
      if (parent.getAttribute("aria-selected") === "true") return true;
      const pCls = (parent.className || "").toLowerCase();
      if (pCls.includes("active") || pCls.includes("selected")) return true;
    }
    return false;
  }
  function waitForGridOrEmpty(kind, timeoutMs = 8e3, abortSignal) {
    return new Promise((resolve) => {
      if (abortSignal?.aborted) {
        resolve({ grid: null, empty: false });
        return;
      }
      const checkImmediate = () => {
        const g = findGrid(document, kind);
        if (g && isVisible(g)) {
          return { grid: g, empty: false };
        }
        const emptyIndicators = findByText(
          {
            contains: [
              "chua co video dang lai",
              "ch\u01B0a c\xF3 video \u0111\u0103ng l\u1EA1i",
              "chua dang lai",
              "ch\u01B0a \u0111\u0103ng l\u1EA1i",
              "no reposted videos yet",
              "no reposts yet",
              "no liked videos yet",
              "chua co video da thich",
              "ch\u01B0a c\xF3 video \u0111\xE3 th\xEDch",
              "no videos yet",
              "chua co video nao",
              "ch\u01B0a c\xF3 video n\xE0o"
            ]
          },
          document.body
        );
        if (emptyIndicators.some((el) => isVisible(el))) {
          return { grid: null, empty: true };
        }
        return null;
      };
      const immediate = checkImmediate();
      if (immediate) {
        resolve(immediate);
        return;
      }
      let settled = false;
      let observer = null;
      let intervalTimer = null;
      let timeoutTimer = null;
      const cleanup = () => {
        if (!settled) {
          settled = true;
          if (observer) observer.disconnect();
          if (intervalTimer) clearInterval(intervalTimer);
          if (timeoutTimer) clearTimeout(timeoutTimer);
          abortSignal?.removeEventListener("abort", onAbort);
        }
      };
      const onAbort = () => {
        cleanup();
        resolve({ grid: null, empty: false });
      };
      abortSignal?.addEventListener("abort", onAbort, { once: true });
      const attempt = () => {
        if (abortSignal?.aborted) {
          onAbort();
          return;
        }
        const res = checkImmediate();
        if (res) {
          cleanup();
          resolve(res);
        }
      };
      try {
        observer = new MutationObserver(() => {
          attempt();
        });
        observer.observe(document.body, { childList: true, subtree: true });
      } catch {
      }
      intervalTimer = setInterval(attempt, 200);
      timeoutTimer = setTimeout(() => {
        const finalRes = checkImmediate();
        cleanup();
        resolve(finalRes || { grid: null, empty: false });
      }, timeoutMs);
    });
  }
  function waitForHydratedGridItems(kind, timeoutMs = 6e3, abortSignal) {
    return new Promise((resolve) => {
      if (abortSignal?.aborted) {
        resolve({ grid: null, anchorCount: 0, empty: false });
        return;
      }
      const inspect = () => {
        const g = findGrid(document, kind);
        if (g && isVisible(g)) {
          const anchors = findVideoAnchors(g);
          if (anchors.length > 0) {
            return { grid: g, anchorCount: anchors.length, empty: false };
          }
        }
        const emptyIndicators = findByText(
          {
            contains: [
              "chua co video dang lai",
              "ch\u01B0a c\xF3 video \u0111\u0103ng l\u1EA1i",
              "chua dang lai",
              "ch\u01B0a \u0111\u0103ng l\u1EA1i",
              "no reposted videos yet",
              "no reposts yet",
              "no liked videos yet",
              "chua co video da thich",
              "ch\u01B0a c\xF3 video \u0111\xE3 th\xEDch",
              "no videos yet",
              "chua co video nao",
              "ch\u01B0a c\xF3 video n\xE0o"
            ]
          },
          document.body
        );
        if (emptyIndicators.some((el) => isVisible(el))) {
          return { grid: g ?? null, anchorCount: 0, empty: true };
        }
        return null;
      };
      const immediate = inspect();
      if (immediate) {
        resolve(immediate);
        return;
      }
      let settled = false;
      let observer = null;
      let intervalTimer = null;
      let timeoutTimer = null;
      const cleanup = () => {
        if (!settled) {
          settled = true;
          observer?.disconnect();
          if (intervalTimer) clearInterval(intervalTimer);
          if (timeoutTimer) clearTimeout(timeoutTimer);
          abortSignal?.removeEventListener("abort", onAbort);
        }
      };
      const onAbort = () => {
        cleanup();
        resolve({ grid: null, anchorCount: 0, empty: false });
      };
      abortSignal?.addEventListener("abort", onAbort, { once: true });
      const attempt = () => {
        if (abortSignal?.aborted) {
          onAbort();
          return;
        }
        const res = inspect();
        if (res) {
          cleanup();
          resolve(res);
        }
      };
      try {
        observer = new MutationObserver(() => attempt());
        observer.observe(document.body, { childList: true, subtree: true });
      } catch {
      }
      intervalTimer = setInterval(attempt, 200);
      timeoutTimer = setTimeout(() => {
        const finalGrid = findGrid(document, kind);
        const count = finalGrid ? findVideoAnchors(finalGrid).length : 0;
        cleanup();
        resolve({ grid: finalGrid ?? null, anchorCount: count, empty: false });
      }, timeoutMs);
    });
  }
  async function openProfileTab(kind, username, abortSignal) {
    if (abortSignal?.aborted) {
      return { ok: false, error: "USER_ABORTED" };
    }
    const path = window.location.pathname.toLowerCase();
    const cleanUsername = username.replace(/^@/, "").toLowerCase();
    const userPath = `/@${cleanUsername}`;
    if (!path.includes(userPath)) {
      return { ok: false, error: "NAVIGATING_TO_PROFILE" };
    }
    let tabBtn = findProfileTabButton(kind, document);
    for (let retry = 0; !tabBtn && retry < 15; retry++) {
      if (abortSignal) {
        const ok = await sleepWithAbort(300, abortSignal);
        if (!ok) return { ok: false, error: "USER_ABORTED" };
      } else {
        await new Promise((r) => setTimeout(r, 300));
      }
      tabBtn = findProfileTabButton(kind, document);
    }
    if (abortSignal?.aborted) {
      return { ok: false, error: "USER_ABORTED" };
    }
    if (tabBtn) {
      const existingGrid = findGrid(document, kind);
      if (isTabActive(tabBtn) && existingGrid && isVisible(existingGrid) && findVideoAnchors(existingGrid).length > 0) {
        return { ok: true };
      }
      if (!isTabActive(tabBtn) || !existingGrid) {
        humanClick(tabBtn);
        try {
          tabBtn.click();
        } catch {
        }
        const inner = tabBtn.querySelector("p, span, div");
        if (inner && inner !== tabBtn) {
          try {
            inner.click();
          } catch {
          }
        }
      }
      const gridState = await waitForGridOrEmpty(kind, 8e3, abortSignal);
      if (abortSignal?.aborted) {
        return { ok: false, error: "USER_ABORTED" };
      }
      if (!gridState.empty) {
        await waitForHydratedGridItems(kind, 6e3, abortSignal);
        if (abortSignal?.aborted) {
          return { ok: false, error: "USER_ABORTED" };
        }
      }
    } else {
      if (!isOwnProfile(document)) {
        const privateTexts = findByText({
          contains: ["videos are private", "video da thich cua nguoi dung nay la rieng tu"]
        });
        if (privateTexts.some((p) => isVisible(p))) {
          return {
            ok: false,
            error: `TAB_PRIVATE: Tab ${kind === "repost" ? "\u0110\u0103ng l\u1EA1i" : "\u0110\xE3 th\xEDch"} c\u1EE7a ng\u01B0\u1EDDi d\xF9ng n\xE0y \u0111ang \u1EDF ch\u1EBF \u0111\u1ED9 ri\xEAng t\u01B0.`
          };
        }
      }
      return {
        ok: false,
        error: `TAB_NOT_FOUND: Kh\xF4ng t\xECm th\u1EA5y tab ${kind === "repost" ? "\u0110\u0103ng l\u1EA1i (Reposts)" : "\u0110\xE3 th\xEDch (Liked)"} tr\xEAn trang c\xE1 nh\xE2n @${cleanUsername}.`
      };
    }
    return { ok: true };
  }
  var ScanEndDetector = class {
    streak = 0;
    maxStreak;
    lastCount = 0;
    constructor(maxStreak = 8) {
      this.maxStreak = maxStreak;
    }
    recordProgress(foundCount) {
      if (foundCount > this.lastCount) {
        this.lastCount = foundCount;
        this.streak = 0;
        return true;
      }
      this.streak++;
      return false;
    }
    getStreak() {
      return this.streak;
    }
    isStalled() {
      return this.streak >= this.maxStreak;
    }
    hasReachedBottom(container) {
      if (container === window) {
        const scrollHeight = Math.max(
          document.documentElement.scrollHeight,
          document.body.scrollHeight
        );
        const clientHeight = window.innerHeight;
        const currentScroll = window.scrollY || window.pageYOffset;
        return currentScroll + clientHeight >= scrollHeight - 350;
      } else {
        const el = container;
        return el.scrollTop + el.clientHeight >= el.scrollHeight - 350;
      }
    }
    hasEndOfFeedIndicator(doc = document) {
      const endIndicators = findByText(
        {
          contains: [
            "khong con noi dung",
            "kh\xF4ng c\xF2n n\u1ED9i dung",
            "da xem het",
            "\u0111\xE3 xem h\u1EBFt",
            "no more videos",
            "you have reached the end",
            "no more content",
            "kh\xF4ng c\xF3 video n\xE0o kh\xE1c",
            "khong co video nao khac"
          ]
        },
        doc.body
      );
      return endIndicators.some((el) => isVisible(el));
    }
  };
  function detectScrollContainer(grid) {
    let el = grid.parentElement;
    while (el && el !== document.body && el !== document.documentElement) {
      const style = window.getComputedStyle(el);
      const overflowY = style.overflowY;
      if ((overflowY === "auto" || overflowY === "scroll") && el.scrollHeight > el.clientHeight + 100) {
        return el;
      }
      el = el.parentElement;
    }
    return window;
  }
  function performScroll(container, deltaY) {
    if (container === window) {
      window.scrollBy({ top: deltaY, behavior: "smooth" });
    } else {
      container.scrollBy({ top: deltaY, behavior: "smooth" });
    }
  }
  function getScrollPosition(container) {
    if (container === window) {
      return window.scrollY || window.pageYOffset;
    }
    return container.scrollTop;
  }
  function notifyScanDone(kind, resp, haltRun) {
    chrome.runtime.sendMessage({
      type: "SCAN_DONE",
      kind,
      total: resp.total,
      code: resp.code,
      message: resp.message,
      haltRun
    }).catch(() => {
    });
    return resp;
  }
  async function runScan(kind, username, limit, knownIds, providedSecUid, skipApi = false) {
    const scanSignal = resetScanAbort();
    if (detectOffline()) {
      return notifyScanDone(kind, { ok: false, code: "OFFLINE", message: "Kh\xF4ng c\xF3 k\u1EBFt n\u1ED1i m\u1EA1ng.", total: 0 }, true);
    }
    if (detectHttp403(document)) {
      return notifyScanDone(
        kind,
        {
          ok: false,
          code: "HTTP_403",
          message: "TikTok t\u1EEB ch\u1ED1i truy c\u1EADp (HTTP 403). \u0110\xE3 d\u1EEBng an to\xE0n \u0111\u1EC3 b\u1EA3o v\u1EC7 t\xE0i kho\u1EA3n.",
          total: 0
        },
        true
      );
    }
    if (detectCaptcha()) {
      return notifyScanDone(
        kind,
        { ok: false, code: "CAPTCHA", message: "Ph\xE1t hi\u1EC7n CAPTCHA tr\xEAn TikTok. Vui l\xF2ng x\xE1c minh tr\u01B0\u1EDBc khi qu\xE9t.", total: 0 },
        true
      );
    }
    if (!skipApi) {
      let secUid = providedSecUid || null;
      if (!secUid) {
        const session = await fetchPageSession();
        if (isScanAborted()) {
          return notifyScanDone(kind, { ok: true, code: "CANCELLED", message: "Qu\xE1 tr\xECnh qu\xE9t \u0111\xE3 \u0111\u01B0\u1EE3c d\u1EEBng.", total: 0 });
        }
        if (session.http403) {
          return notifyScanDone(
            kind,
            {
              ok: false,
              code: "HTTP_403",
              message: "TikTok t\u1EEB ch\u1ED1i truy c\u1EADp (HTTP 403). \u0110\xE3 d\u1EEBng an to\xE0n.",
              total: 0
            },
            true
          );
        }
        secUid = session.secUid;
      }
      if (secUid) {
        const apiResult = await scanKindViaApi(kind, secUid, username, limit, knownIds, isScanAborted);
        if (isScanAborted() || apiResult.code === "CANCELLED") {
          return notifyScanDone(kind, {
            ok: true,
            code: "CANCELLED",
            message: apiResult.message || "Qu\xE1 tr\xECnh qu\xE9t \u0111\xE3 \u0111\u01B0\u1EE3c d\u1EEBng.",
            total: apiResult.total
          });
        }
        if (apiResult.haltRun) {
          return notifyScanDone(
            kind,
            {
              ok: false,
              code: apiResult.code,
              message: apiResult.message,
              total: apiResult.total
            },
            true
          );
        }
        if (!apiResult.fallbackToDom) {
          return notifyScanDone(kind, {
            ok: apiResult.ok,
            code: apiResult.code,
            message: apiResult.message,
            total: apiResult.total
          });
        }
      }
    }
    if (isScanAborted()) {
      return notifyScanDone(kind, { ok: true, code: "CANCELLED", message: "Qu\xE1 tr\xECnh qu\xE9t \u0111\xE3 \u0111\u01B0\u1EE3c d\u1EEBng.", total: 0 });
    }
    const tabRes = await openProfileTab(kind, username, scanSignal);
    if (isScanAborted() || tabRes.error === "USER_ABORTED") {
      return notifyScanDone(kind, { ok: true, code: "CANCELLED", message: "Qu\xE1 tr\xECnh qu\xE9t \u0111\xE3 \u0111\u01B0\u1EE3c d\u1EEBng.", total: 0 });
    }
    if (!tabRes.ok) {
      const errCode = tabRes.error?.split(":")[0] || "TAB_ERROR";
      return notifyScanDone(kind, {
        ok: false,
        code: errCode,
        message: tabRes.error || "",
        total: 0
      });
    }
    const waitResult = await waitForGridOrEmpty(kind, 8e3, scanSignal);
    if (isScanAborted()) {
      return notifyScanDone(kind, { ok: true, code: "CANCELLED", message: "Qu\xE1 tr\xECnh qu\xE9t \u0111\xE3 \u0111\u01B0\u1EE3c d\u1EEBng.", total: 0 });
    }
    if (waitResult.empty) {
      return notifyScanDone(kind, { ok: true, code: "EMPTY", message: "Tab kh\xF4ng c\xF3 video n\xE0o", total: 0 });
    }
    let grid = waitResult.grid || findGrid(document, kind);
    if (!grid) {
      return notifyScanDone(kind, { ok: false, code: "GRID_NOT_FOUND", message: `Kh\xF4ng t\xECm th\u1EA5y danh s\xE1ch video ${kind}`, total: 0 });
    }
    const scrollContainer = detectScrollContainer(grid);
    if (getScrollPosition(scrollContainer) > 100) {
      if (scrollContainer === window) {
        window.scrollTo({ top: 0, behavior: "auto" });
      } else {
        scrollContainer.scrollTop = 0;
      }
      if (!await sleepUnlessScanAborted(400)) {
        return notifyScanDone(kind, { ok: true, code: "CANCELLED", message: "Qu\xE1 tr\xECnh qu\xE9t \u0111\xE3 \u0111\u01B0\u1EE3c d\u1EEBng.", total: 0 });
      }
    }
    const endDetector = new ScanEndDetector(8);
    const seenIds = new Set(knownIds);
    let totalFound = 0;
    let lastScrollPos = getScrollPosition(scrollContainer);
    let endReason = "COMPLETED";
    while (!isScanAborted() && totalFound < limit) {
      if (detectCaptcha()) {
        endReason = "FAILED";
        break;
      }
      if (detectRateLimit()) {
        endReason = "FAILED";
        break;
      }
      const currentGrid = findGrid(document, kind) || grid;
      if (!currentGrid) {
        endDetector.recordProgress(totalFound);
        if (endDetector.isStalled()) {
          endReason = "STALLED";
          break;
        }
        if (!await sleepUnlessScanAborted(600)) break;
        continue;
      }
      const items = extractAll(currentGrid, kind, window.location.origin, username);
      const newItems = items.filter((it) => !seenIds.has(it.videoId));
      if (isScanAborted()) break;
      if (newItems.length > 0) {
        for (const it of newItems) {
          seenIds.add(it.videoId);
        }
        totalFound += newItems.length;
        endDetector.recordProgress(totalFound);
        chrome.runtime.sendMessage({
          type: "SCAN_BATCH",
          kind,
          items: newItems
        }).catch(() => {
        });
        chrome.runtime.sendMessage({
          type: "SCAN_PROGRESS",
          kind,
          found: totalFound,
          message: `\u0110ang qu\xE9t: \u0111\xE3 t\xECm th\u1EA5y ${totalFound} video...`
        }).catch(() => {
        });
      } else {
        endDetector.recordProgress(totalFound);
      }
      if (totalFound >= limit) {
        endReason = "LIMIT_REACHED";
        break;
      }
      if (endDetector.hasEndOfFeedIndicator(document) && endDetector.getStreak() >= 2) {
        endReason = "COMPLETED";
        break;
      }
      const isLoading = !!document.querySelector(
        '[data-e2e*="loading"], [class*="loading" i], [class*="spinner" i], svg circle[class*="loading" i]'
      );
      if (isLoading && endDetector.getStreak() < 10) {
        if (!await sleepUnlessScanAborted(1400)) break;
        continue;
      }
      if (endDetector.hasReachedBottom(scrollContainer) && endDetector.getStreak() >= 3) {
        endReason = "COMPLETED";
        break;
      }
      if (endDetector.isStalled()) {
        endReason = totalFound > 0 ? "COMPLETED" : "STALLED";
        break;
      }
      if (endDetector.getStreak() >= 3 && endDetector.getStreak() % 2 === 1) {
        performScroll(scrollContainer, -300);
        if (!await sleepUnlessScanAborted(500)) break;
        performScroll(scrollContainer, 600);
        if (!await sleepUnlessScanAborted(1e3)) break;
        continue;
      }
      lastScrollPos = getScrollPosition(scrollContainer);
      performScroll(scrollContainer, window.innerHeight * 1.5);
      if (!await sleepUnlessScanAborted(1100 + Math.random() * 400)) break;
      const currentScrollPos = getScrollPosition(scrollContainer);
      if (currentScrollPos === lastScrollPos && endDetector.getStreak() >= 2) {
        if (scrollContainer === window) {
          window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "smooth" });
        } else {
          scrollContainer.scrollTop = scrollContainer.scrollHeight;
        }
        if (!await sleepUnlessScanAborted(900)) break;
      }
    }
    if (isScanAborted()) {
      endReason = "CANCELLED";
    }
    const successMsg = `Qu\xE9t th\xE0nh c\xF4ng! \u0110\xE3 t\xECm th\u1EA5y ${totalFound} video.`;
    const finalResponse = {
      ok: endReason !== "FAILED",
      code: endReason,
      message: isScanAborted() ? "Qu\xE1 tr\xECnh qu\xE9t \u0111\xE3 \u0111\u01B0\u1EE3c d\u1EEBng." : successMsg,
      total: totalFound
    };
    chrome.runtime.sendMessage({
      type: "SCAN_DONE",
      kind,
      total: totalFound,
      code: endReason,
      message: finalResponse.message
    }).catch(() => {
    });
    return finalResponse;
  }

  // src/content/like-handler.ts
  var BROWSE_SELECTORS = [
    'div[data-e2e="browse-video"]',
    'div[data-e2e="browse-container"]',
    '[data-e2e="browse-video-container"]',
    "#main-content-video_detail",
    'div[class*="DivBrowserModeContainer"]',
    'div[class*="DivVideoDetailContainer"]'
  ];
  var FEED_SELECTORS = [
    'div[data-e2e="recommend-list-item-container"]',
    'div[data-e2e="feed-video"]'
  ];
  var CONTAINER_SELECTORS = [...BROWSE_SELECTORS, ...FEED_SELECTORS];
  var COMMENT_ZONE_SEL = '[data-e2e*="comment" i], [class*="Comment" i], [data-e2e*="reply" i], [class*="ReplyAction" i]';
  var LIKE_E2E_RE = /(^|-)(un)?like(-icon|-button)?$/i;
  var TIKTOK_RED_RE = /(#fe2c55\b|#ff2c55\b|#ff3b5c\b|rgba?\(\s*(?:254\s*,\s*44\s*,\s*85|255\s*,\s*44\s*,\s*85|255\s*,\s*59\s*,\s*92)\s*[,)])/i;
  var NEUTRAL_HEART_FILL_RE = /(#fff(?:fff)?\b|rgba?\(\s*(?:255\s*,\s*255\s*,\s*255|254\s*,\s*254\s*,\s*254)\s*[,)])/i;
  var MIN_CONTAINER_AREA = 4e3;
  var inFlightLikeVideos = /* @__PURE__ */ new Set();
  function inComments(el) {
    if (!el) return false;
    return Boolean(el.closest(COMMENT_ZONE_SEL));
  }
  function visibleArea(el) {
    if (!el || !el.isConnected) return 0;
    const h = el;
    const doc = h.ownerDocument ?? document;
    const win = doc.defaultView ?? window;
    const style = win.getComputedStyle?.(h);
    if (style && (style.display === "none" || style.visibility === "hidden" || style.opacity === "0")) {
      return 0;
    }
    const r = h.getBoundingClientRect();
    const hasMockedOrRealRect = r.width > 0 || r.height > 0 || r.top !== 0 || r.left !== 0;
    const bodyRect = doc.body?.getBoundingClientRect();
    const hasBrowserLayout = Boolean(bodyRect && (bodyRect.width > 0 || bodyRect.height > 0));
    if (!hasMockedOrRealRect && !hasBrowserLayout) {
      return isVisible(h) ? 1e5 : 0;
    }
    const vw = win.innerWidth || bodyRect?.width || 1280;
    const vh = win.innerHeight || bodyRect?.height || 800;
    const w = Math.max(0, Math.min(r.right, vw) - Math.max(r.left, 0));
    const hPx = Math.max(0, Math.min(r.bottom, vh) - Math.max(r.top, 0));
    return w * hPx;
  }
  function viewerKind(doc = document) {
    for (const sel of BROWSE_SELECTORS) {
      if (qsa(sel, doc).some((el) => visibleArea(el) > MIN_CONTAINER_AREA)) {
        return "browse";
      }
    }
    for (const sel of FEED_SELECTORS) {
      if (qsa(sel, doc).some((el) => visibleArea(el) > MIN_CONTAINER_AREA)) {
        return "feed";
      }
    }
    return null;
  }
  function activeContainers(doc = document) {
    const kind = viewerKind(doc);
    const selectors = kind === "browse" ? BROWSE_SELECTORS : CONTAINER_SELECTORS;
    const seen = /* @__PURE__ */ new Set();
    const scored = [];
    for (const sel of selectors) {
      for (const el of qsa(sel, doc)) {
        if (seen.has(el)) continue;
        const area = visibleArea(el);
        if (area > MIN_CONTAINER_AREA) {
          seen.add(el);
          scored.push({ el, area });
        }
      }
    }
    scored.sort((a, b) => b.area - a.area);
    return scored.map((s) => s.el);
  }
  function resolveButtonTarget(el, roots) {
    const btn = el.closest('button, [role="button"]');
    if (btn && !inComments(btn) && roots.some((r) => r.contains(btn))) {
      return btn;
    }
    return el;
  }
  function findLikeButton(explicitRoot) {
    const roots = explicitRoot ? [explicitRoot] : activeContainers(document);
    if (roots.length === 0) return null;
    for (const root of roots) {
      const primary = qsa('[data-e2e="browse-like-icon"], [data-e2e="like-icon"]', root);
      for (const el of primary) {
        if (inComments(el) || !isVisible(el)) continue;
        return resolveButtonTarget(el, roots);
      }
    }
    for (const root of roots) {
      const candidates = qsa("[data-e2e]", root);
      for (const el of candidates) {
        if (inComments(el) || !isVisible(el)) continue;
        const e2e = el.getAttribute("data-e2e") || "";
        if (LIKE_E2E_RE.test(e2e) && !/count|comment/i.test(e2e)) {
          return resolveButtonTarget(el, roots);
        }
      }
    }
    for (const root of roots) {
      const buttons = qsa(
        'button[aria-label], [role="button"][aria-label], button[title], [role="button"][title]',
        root
      );
      for (const btn of buttons) {
        if (inComments(btn) || !isVisible(btn)) continue;
        const raw = (btn.getAttribute("aria-label") || btn.getAttribute("title") || "").trim();
        const norm = normalizeText(raw);
        if (/comment|binh luan|share|chia se|repost|dang lai|bookmark|yeu thich/i.test(norm)) continue;
        if (/\b(unlike|like)\b/i.test(raw) || /\b(bo thich|da thich|thich)\b/.test(norm)) {
          return btn;
        }
      }
    }
    return null;
  }
  function readNodeFills(node, allowComputed = true) {
    const values = [];
    const fillAttr = node.getAttribute("fill");
    if (fillAttr && fillAttr !== "none" && fillAttr !== "transparent") {
      values.push(fillAttr);
    }
    const inlineStyle = node.style;
    if (inlineStyle?.fill && inlineStyle.fill !== "none") values.push(inlineStyle.fill);
    if (inlineStyle?.color && fillAttr === "currentColor") values.push(inlineStyle.color);
    if (allowComputed) {
      try {
        const win = node.ownerDocument?.defaultView ?? window;
        const cs = win.getComputedStyle(node);
        if (cs?.fill && cs.fill !== "none") values.push(cs.fill);
        if (cs?.color && fillAttr === "currentColor") values.push(cs.color);
      } catch {
      }
    }
    return values;
  }
  function hasExplicitLikeHook(el) {
    const selfE2e = el.getAttribute("data-e2e") || "";
    if (LIKE_E2E_RE.test(selfE2e)) return true;
    if (el.querySelector('[data-e2e="browse-like-icon"], [data-e2e="like-icon"]')) return true;
    for (const child of qsa("[data-e2e]", el)) {
      const v = child.getAttribute("data-e2e") || "";
      if (LIKE_E2E_RE.test(v) && !/count|comment/i.test(v)) return true;
    }
    return false;
  }
  function inspectLikeButton(el) {
    if (!el) return { state: null, signal: "missing_element" };
    const targets = [el];
    const ancestorBtn = el.closest('button, [role="button"]');
    if (ancestorBtn && ancestorBtn !== el && !inComments(ancestorBtn)) {
      targets.push(ancestorBtn);
    }
    const innerBtn = el.querySelector('button, [role="button"]');
    if (innerBtn && !targets.includes(innerBtn) && !inComments(innerBtn)) {
      targets.push(innerBtn);
    }
    const innerPressed = el.querySelector("[aria-pressed]");
    if (innerPressed && !targets.includes(innerPressed) && !inComments(innerPressed)) {
      targets.push(innerPressed);
    }
    for (const t of targets) {
      const pressed = t.getAttribute("aria-pressed");
      if (pressed === "true") return { state: true, signal: "aria-pressed=true" };
      if (pressed === "false") return { state: false, signal: "aria-pressed=false" };
    }
    for (const t of targets) {
      const raw = (t.getAttribute("aria-label") || t.getAttribute("title") || "").trim();
      if (!raw) continue;
      const norm = normalizeText(raw);
      if (/\bunlike\b/i.test(raw) || /\bbo thich\b/.test(norm)) {
        return { state: true, signal: `aria-label="${raw}"` };
      }
      if (/^like\b/i.test(raw) || /^thich\b/.test(norm)) {
        return { state: false, signal: `aria-label="${raw}"` };
      }
      if (/\bliked\b/i.test(raw) && !/\bliked\s+by\b/i.test(raw) || /\bda thich\b/.test(norm) && !/\bda thich boi\b/.test(norm)) {
        return { state: true, signal: `aria-label="${raw}"` };
      }
    }
    for (const u of qsa("use", el)) {
      const href = (u.getAttribute("href") || u.getAttribute("xlink:href") || "").toLowerCase();
      if (!href) continue;
      if (href.includes("unfill") || href.includes("outline")) {
        return { state: false, signal: `svg-use="${href}"` };
      }
      if (href.includes("fill") || href.includes("liked")) {
        return { state: true, signal: `svg-use="${href}"` };
      }
    }
    const graphicNodes = [
      el,
      ...qsa('[data-e2e*="like" i], svg, path, g, circle', el)
    ];
    for (const node of graphicNodes) {
      if (inComments(node)) continue;
      for (const val of readNodeFills(node, true)) {
        if (TIKTOK_RED_RE.test(val)) {
          return { state: true, signal: `svg-red-fill="${val}"` };
        }
      }
    }
    if (hasExplicitLikeHook(el)) {
      const shapeNodes = qsa("path, svg, use, circle", el);
      for (const shape of shapeNodes) {
        if (inComments(shape)) continue;
        for (const val of readNodeFills(shape, true)) {
          if (NEUTRAL_HEART_FILL_RE.test(val)) {
            return { state: false, signal: `svg-neutral-fill="${val}"` };
          }
        }
      }
    }
    return { state: null, signal: "indeterminate_dom" };
  }
  function isLiked(el) {
    return inspectLikeButton(el).state;
  }
  function readLikeStateAgain(previousBtn, explicitRoot) {
    const fresh = findLikeButton(explicitRoot);
    if (fresh) return isLiked(fresh);
    if (previousBtn && previousBtn.isConnected) return isLiked(previousBtn);
    return null;
  }
  function extractVideoIdFromUrl(urlOrPath) {
    const m = urlOrPath.match(/\/(?:video|photo)\/(\d+)/);
    return m ? m[1] : null;
  }
  function verifyLikedViewerGuard(expectedVideoId, doc = document) {
    const kind = viewerKind(doc);
    if (kind === "feed") {
      return {
        ok: false,
        code: "WRONG_FEED_GUARD",
        message: "Ph\xE1t hi\u1EC7n b\u1EA3ng tin D\xE0nh cho b\u1EA1n (For You) thay v\xEC danh s\xE1ch \u0110\xE3 th\xEDch. \u0110\xE3 t\u1EA1m d\u1EEBng an to\xE0n.",
        haltRun: true
      };
    }
    const deselectedLikedTab = doc.querySelector('[data-e2e="liked-tab"][aria-selected="false"]');
    if (deselectedLikedTab && isVisible(deselectedLikedTab)) {
      return {
        ok: false,
        code: "LIKED_TAB_DESELECTED",
        message: "Tab \u0110\xE3 th\xEDch (Likes) kh\xF4ng c\xF2n \u0111\u01B0\u1EE3c ch\u1ECDn tr\xEAn trang c\xE1 nh\xE2n. \u0110\xE3 t\u1EA1m d\u1EEBng \u0111\u1EC3 tr\xE1nh thao t\xE1c nh\u1EA7m.",
        haltRun: true
      };
    }
    if (expectedVideoId) {
      const urlVideoId = extractVideoIdFromUrl(doc.location?.pathname || "");
      if (urlVideoId && urlVideoId !== expectedVideoId) {
        return {
          ok: false,
          code: "VIDEO_ID_MISMATCH",
          message: `Tr\xECnh ph\xE1t \u0111ang hi\u1EC3n th\u1ECB video ${urlVideoId} thay v\xEC ${expectedVideoId}. \u0110\xE3 d\u1EEBng thao t\xE1c tr\xEAn video n\xE0y \u0111\u1EC3 tr\xE1nh b\u1ECF tim nh\u1EA7m.`
        };
      }
    }
    return { ok: true };
  }
  function waitForDomCondition(predicate, options) {
    const {
      timeoutMs,
      pollMs = 120,
      observeRoot = document.body || document.documentElement,
      observeAttributes = true,
      watchMediaEvents = false,
      abortSignal
    } = options;
    return new Promise((resolve) => {
      if (abortSignal?.aborted) {
        resolve({ value: null, aborted: true });
        return;
      }
      const initial = predicate();
      if (initial !== null) {
        resolve({ value: initial, aborted: false });
        return;
      }
      if (timeoutMs <= 0) {
        resolve({ value: null, aborted: false });
        return;
      }
      let settled = false;
      let observer = null;
      let pollTimer = null;
      let deadlineTimer = null;
      const attachedVideos = /* @__PURE__ */ new Set();
      const onMediaEvent = () => check();
      const attachVideoListeners = () => {
        if (!watchMediaEvents) return;
        for (const v of qsa("video", document)) {
          if (attachedVideos.has(v)) continue;
          attachedVideos.add(v);
          v.addEventListener("loadedmetadata", onMediaEvent, { once: true });
          v.addEventListener("loadeddata", onMediaEvent, { once: true });
          v.addEventListener("canplay", onMediaEvent, { once: true });
        }
      };
      const cleanup = () => {
        if (settled) return;
        settled = true;
        observer?.disconnect();
        if (pollTimer) clearInterval(pollTimer);
        if (deadlineTimer) clearTimeout(deadlineTimer);
        abortSignal?.removeEventListener("abort", onAbort);
        for (const v of attachedVideos) {
          v.removeEventListener("loadedmetadata", onMediaEvent);
          v.removeEventListener("loadeddata", onMediaEvent);
          v.removeEventListener("canplay", onMediaEvent);
        }
        attachedVideos.clear();
      };
      const onAbort = () => {
        cleanup();
        resolve({ value: null, aborted: true });
      };
      const check = () => {
        if (settled) return;
        if (abortSignal?.aborted) {
          onAbort();
          return;
        }
        attachVideoListeners();
        const val = predicate();
        if (val !== null) {
          cleanup();
          resolve({ value: val, aborted: false });
        }
      };
      abortSignal?.addEventListener("abort", onAbort, { once: true });
      attachVideoListeners();
      try {
        if (observeRoot) {
          observer = new MutationObserver(() => check());
          observer.observe(observeRoot, {
            childList: true,
            subtree: true,
            attributes: observeAttributes,
            ...observeAttributes ? {
              attributeFilter: [
                "aria-pressed",
                "aria-label",
                "title",
                "data-e2e",
                "fill",
                "class",
                "style",
                "src",
                "href",
                "data-loading"
              ]
            } : {}
          });
        }
      } catch {
      }
      pollTimer = setInterval(check, pollMs);
      deadlineTimer = setTimeout(() => {
        const finalVal = predicate();
        cleanup();
        resolve({ value: finalVal, aborted: Boolean(abortSignal?.aborted) });
      }, timeoutMs);
    });
  }
  function isVideoElementStillLoading(containers) {
    for (const c of containers) {
      const videos = qsa("video", c);
      for (const v of videos) {
        if (v.getAttribute("data-loading") === "true") return true;
        const hasExplicitStream = Boolean(v.getAttribute("src") || v.querySelector("source"));
        const srcVal = v.getAttribute("src") || "";
        if (hasExplicitStream && /^https?:/i.test(srcVal) && v.readyState === 0) {
          return true;
        }
      }
    }
    return false;
  }
  async function removeLike(videoId, _targetUrl, timings = {}) {
    const {
      videoReadyWaitMs = 4500,
      buttonWaitMs = 8e3,
      buttonMaxRetries = 5,
      hydrationWaitMs = 4e3,
      unlikedConfirmWaitMs = timings.hydrationWaitMs !== void 0 ? Math.min(1600, Math.max(60, timings.hydrationWaitMs)) : 1600,
      preClickDelayMs = 240,
      postClickDelayMs = 380,
      verifyTimeoutMs = 5500,
      verifyPollMs = 180,
      settleConfirmMs = 450,
      initialTrace,
      onStageChange
    } = timings;
    const abortSignal = getActionAbortSignal();
    const trace = [];
    const enterStage = (stage) => {
      if (trace[trace.length - 1] !== stage) {
        trace.push(stage);
        onStageChange?.(stage);
      }
    };
    if (initialTrace && initialTrace.length > 0) {
      for (const st of initialTrace) enterStage(st);
    } else {
      enterStage("OPENING");
    }
    const finish = (status, terminalStage, code, message, extra) => {
      enterStage(terminalStage);
      if (status === "skipped") {
        const reason = extra?.skipReason || code;
        console.info(
          `[TikTokCleanerPro][LikeFlow][SKIPPED] videoId=${videoId} reason=${reason} trace=${trace.join(" -> ")} msg=${message}`
        );
      }
      return {
        status,
        code,
        message,
        stage: terminalStage,
        trace: [...trace],
        ...extra?.haltRun ? { haltRun: true } : {},
        ...extra?.skipReason ? { skipReason: extra.skipReason } : {}
      };
    };
    if (inFlightLikeVideos.has(videoId)) {
      return finish(
        "unverified",
        "UNVERIFIED",
        "DUPLICATE_IN_FLIGHT",
        `Video ${videoId} \u0111ang \u0111\u01B0\u1EE3c x\u1EED l\xFD \u1EDF t\xE1c v\u1EE5 kh\xE1c \u2014 b\u1ECF qua l\u01B0\u1EE3t tr\xF9ng \u0111\u1EC3 tr\xE1nh nh\u1EA5n tim l\u1EA1i.`
      );
    }
    inFlightLikeVideos.add(videoId);
    let clickedOnce = false;
    try {
      if (isActionAborted()) {
        return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
      }
      const checkSafetyHalt = () => {
        if (detectOffline()) {
          return finish("failed", "FAILED", "OFFLINE", "Kh\xF4ng c\xF3 k\u1EBFt n\u1ED1i m\u1EA1ng", { haltRun: true });
        }
        if (detectHttp403(document)) {
          return finish(
            "failed",
            "FAILED",
            "HTTP_403",
            "TikTok t\u1EEB ch\u1ED1i truy c\u1EADp (HTTP 403). \u0110\xE3 t\u1EA1m d\u1EEBng \u0111\u1EC3 b\u1EA3o v\u1EC7 t\xE0i kho\u1EA3n.",
            { haltRun: true }
          );
        }
        if (detectCaptcha()) {
          return finish(
            "failed",
            "FAILED",
            "CAPTCHA",
            "Ph\xE1t hi\u1EC7n CAPTCHA tr\xEAn TikTok. Vui l\xF2ng ho\xE0n t\u1EA5t x\xE1c minh.",
            { haltRun: true }
          );
        }
        if (detectRateLimit()) {
          return finish(
            "failed",
            "FAILED",
            "RATE_LIMIT",
            "TikTok gi\u1EDBi h\u1EA1n t\u1ED1c \u0111\u1ED9 thao t\xE1c. \u0110\xE3 t\u1EA1m d\u1EEBng an to\xE0n.",
            { haltRun: true }
          );
        }
        return null;
      };
      const initialHalt = checkSafetyHalt();
      if (initialHalt) return initialHalt;
      if (detectUnavailable()) {
        return finish(
          "unavailable",
          "FAILED",
          "VIDEO_UNAVAILABLE",
          "Video kh\xF4ng kh\u1EA3 d\u1EE5ng, ri\xEAng t\u01B0 ho\u1EB7c \u0111\xE3 b\u1ECB x\xF3a"
        );
      }
      enterStage("WAITING_FOR_VIDEO");
      const immediateGuard = verifyLikedViewerGuard(videoId, document);
      if (!immediateGuard.ok && immediateGuard.haltRun) {
        return finish(
          "failed",
          "FAILED",
          immediateGuard.code || "VIEWER_GUARD_FAILED",
          immediateGuard.message || "Tr\xECnh ph\xE1t video kh\xF4ng h\u1EE3p l\u1EC7",
          { haltRun: true }
        );
      }
      const videoWaitBudget = Math.min(videoReadyWaitMs, Math.max(120, buttonWaitMs));
      const viewerReady = await waitForDomCondition(
        () => {
          if (detectUnavailable() || detectHttp403(document) || detectCaptcha() || detectRateLimit()) {
            return [];
          }
          const guard = verifyLikedViewerGuard(videoId, document);
          if (!guard.ok) {
            if (guard.haltRun) return [];
            return null;
          }
          const containers = activeContainers(document);
          if (containers.length === 0) return null;
          const existingBtn = findLikeButton();
          if (existingBtn && isLiked(existingBtn) === true) {
            return containers;
          }
          if (isVideoElementStillLoading(containers)) {
            return null;
          }
          return containers;
        },
        {
          timeoutMs: videoWaitBudget,
          pollMs: 100,
          watchMediaEvents: true,
          abortSignal
        }
      );
      if (viewerReady.aborted || isActionAborted()) {
        return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
      }
      const postVideoHalt = checkSafetyHalt();
      if (postVideoHalt) return postVideoHalt;
      if (detectUnavailable()) {
        return finish(
          "unavailable",
          "FAILED",
          "VIDEO_UNAVAILABLE",
          "Video kh\xF4ng kh\u1EA3 d\u1EE5ng, ri\xEAng t\u01B0 ho\u1EB7c \u0111\xE3 b\u1ECB x\xF3a"
        );
      }
      const preGuard = verifyLikedViewerGuard(videoId, document);
      if (!preGuard.ok) {
        return finish(
          preGuard.code === "VIDEO_ID_MISMATCH" ? "failed" : "unverified",
          preGuard.code === "VIDEO_ID_MISMATCH" ? "FAILED" : "UNVERIFIED",
          preGuard.code || "VIEWER_GUARD_FAILED",
          preGuard.message || "Tr\xECnh ph\xE1t video kh\xF4ng h\u1EE3p l\u1EC7",
          { haltRun: preGuard.haltRun }
        );
      }
      enterStage("WAITING_FOR_LIKE_BUTTON");
      let likeBtn = findLikeButton();
      const retries = Math.max(1, buttonMaxRetries);
      const sliceMs = Math.max(40, Math.floor(buttonWaitMs / retries));
      for (let attempt = 0; !likeBtn && attempt < retries; attempt++) {
        const btnWait = await waitForDomCondition(
          () => {
            if (detectUnavailable() || detectHttp403(document) || detectCaptcha() || detectRateLimit()) {
              return document.body;
            }
            return findLikeButton();
          },
          {
            timeoutMs: sliceMs,
            pollMs: Math.min(120, Math.max(25, Math.floor(sliceMs / 3))),
            observeAttributes: true,
            abortSignal
          }
        );
        if (btnWait.aborted || isActionAborted()) {
          return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
        }
        const safety = checkSafetyHalt();
        if (safety) return safety;
        if (detectUnavailable()) {
          return finish(
            "unavailable",
            "FAILED",
            "VIDEO_UNAVAILABLE",
            "Video kh\xF4ng kh\u1EA3 d\u1EE5ng, ri\xEAng t\u01B0 ho\u1EB7c \u0111\xE3 b\u1ECB x\xF3a"
          );
        }
        likeBtn = findLikeButton();
      }
      if (!likeBtn) {
        return finish(
          "unverified",
          "UNVERIFIED",
          "LIKE_BUTTON_NOT_FOUND",
          "Kh\xF4ng t\xECm th\u1EA5y n\xFAt Tim sau khi ch\u1EDD DOM t\u1EA3i xong \u2014 \u0111\xE1nh d\u1EA5u UNVERIFIED (kh\xF4ng t\u1EF1 SKIPPED)."
        );
      }
      enterStage("CHECKING_LIKE");
      let inspection = inspectLikeButton(likeBtn);
      if (inspection.state === null) {
        const hydrated = await waitForDomCondition(
          () => {
            const fresh = findLikeButton() ?? likeBtn;
            const cur = inspectLikeButton(fresh);
            return cur.state !== null ? cur : null;
          },
          {
            timeoutMs: hydrationWaitMs,
            pollMs: Math.min(120, Math.max(25, Math.floor(hydrationWaitMs / 4))),
            observeAttributes: true,
            watchMediaEvents: true,
            abortSignal
          }
        );
        if (hydrated.aborted || isActionAborted()) {
          return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
        }
        likeBtn = findLikeButton() ?? likeBtn;
        inspection = hydrated.value ?? inspectLikeButton(likeBtn);
      }
      if (inspection.state === false) {
        const containers = activeContainers(document);
        const effectiveConfirmMs = isVideoElementStillLoading(containers) ? Math.max(unlikedConfirmWaitMs, hydrationWaitMs) : unlikedConfirmWaitMs;
        let consecutiveFalseReads = 1;
        let lastFalseSignal = inspection.signal;
        const confirmStart = Date.now();
        const sampleInterval = Math.max(20, Math.floor(effectiveConfirmMs / 3));
        while (Date.now() - confirmStart < effectiveConfirmMs) {
          const remaining = effectiveConfirmMs - (Date.now() - confirmStart);
          const stepWait = Math.min(sampleInterval, Math.max(15, remaining));
          const flipped = await waitForDomCondition(
            () => {
              const fresh = findLikeButton();
              if (!fresh) return { state: null, signal: "button_detached_during_check" };
              const cur = inspectLikeButton(fresh);
              if (cur.state === true || cur.state === null) return cur;
              return null;
            },
            {
              timeoutMs: stepWait,
              pollMs: Math.max(20, Math.floor(stepWait / 2)),
              observeAttributes: true,
              watchMediaEvents: true,
              abortSignal
            }
          );
          if (flipped.aborted || isActionAborted()) {
            return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
          }
          const safety = checkSafetyHalt();
          if (safety) return safety;
          if (detectUnavailable()) {
            return finish(
              "unavailable",
              "FAILED",
              "VIDEO_UNAVAILABLE",
              "Video kh\xF4ng kh\u1EA3 d\u1EE5ng, ri\xEAng t\u01B0 ho\u1EB7c \u0111\xE3 b\u1ECB x\xF3a"
            );
          }
          if (flipped.value?.state === true) {
            likeBtn = findLikeButton() ?? likeBtn;
            inspection = flipped.value;
            break;
          }
          if (flipped.value?.state === null) {
            const settledAfterNull = await waitForDomCondition(
              () => {
                const fresh = findLikeButton();
                if (!fresh) return null;
                const cur = inspectLikeButton(fresh);
                return cur.state !== null ? cur : null;
              },
              {
                timeoutMs: Math.max(80, hydrationWaitMs - (Date.now() - confirmStart)),
                pollMs: 80,
                observeAttributes: true,
                abortSignal
              }
            );
            if (settledAfterNull.aborted || isActionAborted()) {
              return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
            }
            likeBtn = findLikeButton() ?? likeBtn;
            inspection = settledAfterNull.value ?? inspectLikeButton(likeBtn);
            if (inspection.state !== false) break;
          }
          const freshBtn = findLikeButton();
          if (!freshBtn) {
            inspection = { state: null, signal: "button_lost_during_check" };
            break;
          }
          likeBtn = freshBtn;
          const sample = inspectLikeButton(freshBtn);
          inspection = sample;
          if (sample.state === true || sample.state === null) {
            break;
          }
          consecutiveFalseReads += 1;
          lastFalseSignal = sample.signal;
        }
        if (inspection.state === false) {
          const skipGuard = verifyLikedViewerGuard(videoId, document);
          if (!skipGuard.ok) {
            return finish(
              "unverified",
              "UNVERIFIED",
              skipGuard.code || "VIEWER_GUARD_FAILED",
              skipGuard.message || "Kh\xF4ng th\u1EC3 x\xE1c minh \u0111\xFAng video tr\u01B0\u1EDBc khi \u0111\xE1nh d\u1EA5u SKIPPED",
              { haltRun: skipGuard.haltRun }
            );
          }
          const skipReason = `CONFIRMED_ALREADY_UNLIKED (${lastFalseSignal}, samples=${consecutiveFalseReads})`;
          return finish(
            "skipped",
            "SKIPPED",
            "ALREADY_UNLIKED",
            `\u0110\xE3 b\u1ECF qua: X\xE1c minh video \u0111\xE3 \u1EDF tr\u1EA1ng th\xE1i ch\u01B0a th\xEDch t\u1EEB tr\u01B0\u1EDBc (${lastFalseSignal}, ki\u1EC3m tra ${consecutiveFalseReads} l\u1EA7n).`,
            { skipReason }
          );
        }
      }
      if (inspection.state === null) {
        return finish(
          "unverified",
          "UNVERIFIED",
          "INDETERMINATE_LIKE_STATE",
          `Kh\xF4ng x\xE1c \u0111\u1ECBnh ch\u1EAFc ch\u1EAFn tr\u1EA1ng th\xE1i n\xFAt Tim (${inspection.signal}) \u2014 \u0111\xE1nh d\u1EA5u UNVERIFIED, kh\xF4ng click \u0111\u1EC3 tr\xE1nh tim l\u1EA1i video.`
        );
      }
      enterStage("UNLIKING");
      const clickGuard = verifyLikedViewerGuard(videoId, document);
      if (!clickGuard.ok) {
        return finish(
          clickGuard.code === "VIDEO_ID_MISMATCH" ? "failed" : "unverified",
          clickGuard.code === "VIDEO_ID_MISMATCH" ? "FAILED" : "UNVERIFIED",
          clickGuard.code || "VIEWER_GUARD_FAILED",
          clickGuard.message || "Tr\xECnh ph\xE1t video \u0111\xE3 thay \u0111\u1ED5i tr\u01B0\u1EDBc khi b\u1ECF tim",
          { haltRun: clickGuard.haltRun }
        );
      }
      if (preClickDelayMs > 0) {
        if (!await sleepUnlessActionAborted(preClickDelayMs)) {
          return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
        }
      }
      if (isActionAborted()) {
        return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
      }
      const liveBtn = findLikeButton() ?? likeBtn;
      const preClickInspection = inspectLikeButton(liveBtn);
      if (preClickInspection.state === null) {
        return finish(
          "unverified",
          "UNVERIFIED",
          "INDETERMINATE_BEFORE_CLICK",
          "Tr\u1EA1ng th\xE1i n\xFAt Tim tr\u1EDF n\xEAn kh\xF4ng x\xE1c \u0111\u1ECBnh ngay tr\u01B0\u1EDBc khi nh\u1EA5n \u2014 \u0111\xE3 h\u1EE7y click \u0111\u1EC3 tr\xE1nh tim l\u1EA1i."
        );
      }
      if (preClickInspection.state === false) {
        const skipReason = `CONFIRMED_UNLIKED_PRE_CLICK (${preClickInspection.signal})`;
        return finish(
          "skipped",
          "SKIPPED",
          "ALREADY_UNLIKED",
          `\u0110\xE3 b\u1ECF qua: N\xFAt Tim \u0111\xE3 \u1EDF tr\u1EA1ng th\xE1i b\u1ECF th\xEDch tr\u01B0\u1EDBc khi click (${preClickInspection.signal}).`,
          { skipReason }
        );
      }
      if (clickedOnce) {
        return finish(
          "unverified",
          "UNVERIFIED",
          "SINGLE_CLICK_GUARD",
          "\u0110\xE3 ch\u1EB7n thao t\xE1c click l\u1EB7p tr\xEAn c\xF9ng m\u1ED9t video."
        );
      }
      clickedOnce = true;
      try {
        liveBtn.scrollIntoView?.({ block: "center", inline: "center" });
      } catch {
      }
      liveBtn.click();
      enterStage("VERIFYING");
      if (postClickDelayMs > 0) {
        if (!await sleepUnlessActionAborted(postClickDelayMs)) {
          return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
        }
      }
      const verifyDeadline = Date.now() + verifyTimeoutMs;
      let confirmedUnliked = false;
      while (Date.now() < verifyDeadline) {
        if (isActionAborted()) {
          return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
        }
        const safety = checkSafetyHalt();
        if (safety) return safety;
        const remaining = verifyDeadline - Date.now();
        if (remaining <= 0) break;
        const waitUnliked = await waitForDomCondition(
          () => {
            if (detectHttp403(document) || detectCaptcha() || detectRateLimit()) {
              return true;
            }
            return readLikeStateAgain(liveBtn) === false ? true : null;
          },
          {
            timeoutMs: remaining,
            pollMs: verifyPollMs,
            observeAttributes: true,
            abortSignal
          }
        );
        if (waitUnliked.aborted || isActionAborted()) {
          return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
        }
        const midSafety = checkSafetyHalt();
        if (midSafety) return midSafety;
        if (readLikeStateAgain(liveBtn) === false) {
          if (settleConfirmMs > 0) {
            if (!await sleepUnlessActionAborted(settleConfirmMs)) {
              return finish("failed", "FAILED", "USER_ABORTED", "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng.");
            }
            const postSettleSafety = checkSafetyHalt();
            if (postSettleSafety) return postSettleSafety;
            if (readLikeStateAgain(liveBtn) === false) {
              confirmedUnliked = true;
              break;
            }
          } else {
            confirmedUnliked = true;
            break;
          }
        }
      }
      if (confirmedUnliked) {
        return finish("success", "SUCCESS", "SUCCESS", "\u0110\xE3 b\u1ECF tim v\xE0 x\xE1c minh th\xE0nh c\xF4ng");
      }
      const finalState = readLikeStateAgain(liveBtn);
      if (finalState === null) {
        return finish(
          "unverified",
          "UNVERIFIED",
          "VERIFY_INDETERMINATE",
          "\u0110\xE3 nh\u1EA5n b\u1ECF tim nh\u01B0ng DOM chuy\u1EC3n sang tr\u1EA1ng th\xE1i kh\xF4ng x\xE1c \u0111\u1ECBnh \u2014 \u0111\xE1nh d\u1EA5u UNVERIFIED (kh\xF4ng t\u1EF1 click l\u1EA1i)."
        );
      }
      return finish(
        "failed",
        "FAILED",
        "VERIFY_FAILED",
        "\u0110\xE3 nh\u1EA5n b\u1ECF tim 1 l\u1EA7n nh\u01B0ng TikTok ch\u01B0a c\u1EADp nh\u1EADt sang tr\u1EA1ng th\xE1i ch\u01B0a th\xEDch (kh\xF4ng t\u1EF1 click l\u1EA1i \u0111\u1EC3 tr\xE1nh tim l\u1EA1i)."
      );
    } finally {
      inFlightLikeVideos.delete(videoId);
    }
  }

  // src/services/result-verifier.ts
  function waitFor(probe, opts = {}) {
    const timeout = opts.timeout ?? 8e3;
    const interval = opts.interval ?? 150;
    return new Promise((resolve) => {
      let done = false;
      let observer = null;
      const finish = (v) => {
        if (done) return;
        done = true;
        clearInterval(timer);
        clearTimeout(killer);
        observer?.disconnect();
        resolve(v);
      };
      const check = () => {
        try {
          const v = probe();
          if (v) finish(v);
        } catch {
        }
      };
      const timer = setInterval(check, interval);
      const killer = setTimeout(() => finish(null), timeout);
      if (opts.root && typeof MutationObserver !== "undefined") {
        observer = new MutationObserver(check);
        observer.observe(opts.root, { subtree: true, childList: true, attributes: true, characterData: true });
      }
      check();
    });
  }
  async function verifyTransition(read, expected, opts = {}) {
    const ok = await waitFor(() => read() === expected, { timeout: opts.timeout ?? 6e3, root: opts.root });
    if (!ok) return false;
    const settle = opts.settleMs ?? 1200;
    await new Promise((r) => setTimeout(r, settle));
    return read() === expected;
  }

  // src/content/repost-handler.ts
  var REPOST_BUTTON_SELECTORS = [
    '[data-e2e="browse-repost-icon"]',
    '[data-e2e="repost-button"]',
    '[data-e2e="repost-icon"]',
    'button[aria-label*="repost" i]',
    'button[aria-label*="\u0111\u0103ng l\u1EA1i" i]',
    'button[title*="repost" i]',
    'button[title*="\u0111\u0103ng l\u1EA1i" i]'
  ];
  var SHARE_BUTTON_SELECTORS = [
    '[data-e2e="browse-share-icon"]',
    '[data-e2e="share-button"]',
    '[data-e2e="share-icon"]',
    'button[aria-label*="share" i]',
    'button[aria-label*="chia s\u1EBB" i]'
  ];
  function isRepostedState(el) {
    const ariaPressed = el.getAttribute("aria-pressed");
    if (ariaPressed === "true") return true;
    const label = normalizeText(el.getAttribute("aria-label") || el.getAttribute("title") || el.textContent);
    if (label.includes("remove repost") || label.includes("go dang lai") || label.includes("da dang lai")) {
      return true;
    }
    const svg = el.querySelector("svg");
    if (svg) {
      const fill = svg.getAttribute("fill") || "";
      const style = window.getComputedStyle(svg);
      const color = style.color || style.fill || "";
      if (/face15|250,\s*206,\s*21/i.test(fill) || /face15|250,\s*206,\s*21/i.test(color)) {
        return true;
      }
    }
    return false;
  }
  async function removeRepost(videoId, _targetUrl, options) {
    if (isActionAborted()) {
      return { status: "failed", code: "USER_ABORTED", message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng." };
    }
    if (detectOffline()) {
      return { status: "failed", code: "OFFLINE", message: "Kh\xF4ng c\xF3 k\u1EBFt n\u1ED1i m\u1EA1ng", haltRun: true };
    }
    if (detectHttp403(document)) {
      return {
        status: "failed",
        code: "HTTP_403",
        message: "TikTok t\u1EEB ch\u1ED1i truy c\u1EADp (HTTP 403). \u0110\xE3 t\u1EA1m d\u1EEBng an to\xE0n v\xE0 l\u01B0u ti\u1EBFn \u0111\u1ED9.",
        haltRun: true
      };
    }
    if (detectCaptcha()) {
      return { status: "failed", code: "CAPTCHA", message: "Ph\xE1t hi\u1EC7n CAPTCHA tr\xEAn TikTok. Vui l\xF2ng ho\xE0n t\u1EA5t x\xE1c minh.", haltRun: true };
    }
    if (detectRateLimit()) {
      return { status: "failed", code: "RATE_LIMIT", message: "TikTok gi\u1EDBi h\u1EA1n t\u1ED1c \u0111\u1ED9 thao t\xE1c. \u0110\xE3 t\u1EA1m d\u1EEBng an to\xE0n.", haltRun: true };
    }
    if (!options?.domOnly) {
      try {
        await deleteRepostViaApi(videoId);
        return { status: "success", code: "SUCCESS", message: "\u0110\xE3 x\xF3a \u0111\u0103ng l\u1EA1i th\xE0nh c\xF4ng" };
      } catch (err) {
        if (err instanceof UserAbortError || isActionAborted()) {
          return { status: "failed", code: "USER_ABORTED", message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng." };
        }
        if (err instanceof SafetyStopError) {
          return {
            status: "failed",
            code: err.code,
            message: err.message,
            haltRun: true
          };
        }
        const modalOpen = !!document.querySelector('[data-e2e="browse-video-container"], [data-e2e="browse-close"]');
        if (!modalOpen) {
          return {
            status: "failed",
            code: "API_REPOST_DELETE_FAILED",
            message: err instanceof Error ? err.message : String(err)
          };
        }
      }
    }
    if (isActionAborted()) {
      return { status: "failed", code: "USER_ABORTED", message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng." };
    }
    if (detectUnavailable()) {
      return { status: "unavailable", code: "VIDEO_UNAVAILABLE", message: "Video kh\xF4ng kh\u1EA3 d\u1EE5ng ho\u1EB7c \u0111\xE3 b\u1ECB x\xF3a" };
    }
    let repostBtn = null;
    for (const sel of REPOST_BUTTON_SELECTORS) {
      const el = firstVisible(sel);
      if (el) {
        repostBtn = clickableAncestor(el);
        break;
      }
    }
    let openedShareMenu = false;
    if (!repostBtn) {
      for (const sel of SHARE_BUTTON_SELECTORS) {
        const shareBtn = firstVisible(sel);
        if (shareBtn) {
          humanClick(clickableAncestor(shareBtn));
          openedShareMenu = true;
          if (!await sleepUnlessActionAborted(600)) {
            pressEscape();
            return { status: "failed", code: "USER_ABORTED", message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng." };
          }
          break;
        }
      }
      const removeItems = findByText({
        contains: ["xoa dang lai", "x\xF3a \u0111\u0103ng l\u1EA1i", "go dang lai", "g\u1EE1 \u0111\u0103ng l\u1EA1i", "remove repost", "delete repost"]
      });
      for (const item of removeItems) {
        const ancestor = clickableAncestor(item);
        if (isVisible(ancestor)) {
          repostBtn = ancestor;
          break;
        }
      }
      if (!repostBtn) {
        const repostItems = findByText({
          contains: ["dang lai", "\u0111\u0103ng l\u1EA1i", "repost"]
        });
        for (const item of repostItems) {
          const ancestor = clickableAncestor(item);
          if (isVisible(ancestor)) {
            if (openedShareMenu) pressEscape();
            return {
              status: "skipped",
              code: "ALREADY_NOT_REPOSTED",
              message: "Video \u0111\xE3 kh\xF4ng c\xF2n \u0111\u01B0\u1EE3c \u0111\u0103ng l\u1EA1i"
            };
          }
        }
      }
    }
    if (!repostBtn) {
      if (openedShareMenu) pressEscape();
      return {
        status: "unavailable",
        code: "REPOST_BUTTON_NOT_FOUND",
        message: "TikTok web UI does not offer a Repost removal button for this video (use mobile app)"
      };
    }
    const reposted = isRepostedState(repostBtn);
    const text = normalizeText(repostBtn.textContent || repostBtn.getAttribute("aria-label"));
    if (!reposted && (text.includes("repost") || text.includes("dang lai")) && !text.includes("remove") && !text.includes("go")) {
      if (openedShareMenu) pressEscape();
      return {
        status: "skipped",
        code: "ALREADY_NOT_REPOSTED",
        message: "Video is already not reposted"
      };
    }
    if (isActionAborted()) {
      if (openedShareMenu) pressEscape();
      return { status: "failed", code: "USER_ABORTED", message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng." };
    }
    humanClick(repostBtn);
    await sleep(400);
    const confirmBtns = findByText({
      exact: ["remove", "g\u1EE1", "x\xF3a", "remove repost", "g\u1EE1 \u0111\u0103ng l\u1EA1i", "x\xF3a \u0111\u0103ng l\u1EA1i", "x\xE1c nh\u1EADn"],
      contains: ["x\xF3a \u0111\u0103ng l\u1EA1i", "g\u1EE1 \u0111\u0103ng l\u1EA1i", "remove repost", "x\xE1c nh\u1EADn"]
    });
    for (const cb of confirmBtns) {
      const cAncestor = clickableAncestor(cb);
      if (isVisible(cAncestor) && cAncestor !== repostBtn) {
        humanClick(cAncestor);
        break;
      }
    }
    const verified = await verifyTransition(
      () => {
        if (detectCaptcha() || detectRateLimit()) return "off";
        return isRepostedState(repostBtn) ? "on" : "off";
      },
      "off",
      { timeout: 5e3, settleMs: 800 }
    );
    if (openedShareMenu) {
      pressEscape();
    }
    if (detectCaptcha()) {
      return { status: "failed", code: "CAPTCHA", message: "CAPTCHA detected during action", haltRun: true };
    }
    if (detectRateLimit()) {
      return { status: "failed", code: "RATE_LIMIT", message: "Rate limit encountered after action", haltRun: true };
    }
    if (verified) {
      return { status: "success", code: "SUCCESS", message: "Repost successfully removed" };
    }
    return {
      status: "failed",
      code: "VERIFY_FAILED",
      message: "Could not verify repost removal on TikTok web"
    };
  }

  // src/content/index.ts
  var MODAL_SELECTORS = [
    ...BROWSE_SELECTORS,
    '[data-e2e="browse-close"]',
    '[data-e2e="close-button"]',
    '[data-e2e="browse-like-icon"]',
    '[data-e2e="browse-share-icon"]',
    '[data-e2e="browse-repost-icon"]',
    'div[class*="DetailContainer"]',
    'div[class*="BrowseMode"]'
  ];
  function isModalOpen() {
    if (viewerKind(document) === "browse") return true;
    for (const sel of MODAL_SELECTORS) {
      const el = document.querySelector(sel);
      if (el && isVisible(el)) return true;
    }
    return false;
  }
  function currentViewerVideoSrc() {
    for (const sel of BROWSE_SELECTORS) {
      const v = document.querySelector(`${sel} video`);
      if (v && (v.currentSrc || v.src)) return v.currentSrc || v.src;
    }
    return null;
  }
  function waitForModal(timeoutMs = 6e3, expectedVideoId, previousVideoSrc) {
    const abortSignal = getActionAbortSignal();
    return new Promise((resolve) => {
      if (abortSignal.aborted) {
        resolve(false);
        return;
      }
      const isReady = () => {
        if (!isModalOpen()) return false;
        const urlVid = extractVideoIdFromUrl(window.location.pathname);
        if (expectedVideoId && urlVid && urlVid !== expectedVideoId) {
          return false;
        }
        if (previousVideoSrc) {
          const curSrc = currentViewerVideoSrc();
          if (curSrc && curSrc === previousVideoSrc && (!urlVid || urlVid !== expectedVideoId)) {
            return false;
          }
        }
        return true;
      };
      if (isReady()) {
        resolve(true);
        return;
      }
      let settled = false;
      let observer = null;
      let pollTimer = null;
      let timeoutTimer = null;
      const cleanup = () => {
        if (settled) return;
        settled = true;
        observer?.disconnect();
        if (pollTimer) clearInterval(pollTimer);
        if (timeoutTimer) clearTimeout(timeoutTimer);
        abortSignal.removeEventListener("abort", onAbort);
      };
      const onAbort = () => {
        cleanup();
        resolve(false);
      };
      const check = () => {
        if (abortSignal.aborted) {
          onAbort();
          return;
        }
        if (isReady()) {
          cleanup();
          resolve(true);
        }
      };
      abortSignal.addEventListener("abort", onAbort, { once: true });
      try {
        observer = new MutationObserver(() => check());
        observer.observe(document.body, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["data-e2e", "class", "style", "src", "aria-pressed"]
        });
      } catch {
      }
      pollTimer = setInterval(check, 120);
      timeoutTimer = setTimeout(() => {
        const ok = isReady();
        cleanup();
        resolve(ok);
      }, timeoutMs);
    });
  }
  async function closeModal(expectedProfileAccount) {
    const onVideoRoute = () => Boolean(extractVideoIdFromUrl(window.location.pathname));
    if (!isModalOpen() && !onVideoRoute()) return;
    const closeSelectors = [
      '[data-e2e="browse-close"]',
      '[data-e2e="close-button"]',
      'button[aria-label*="close" i]',
      'button[aria-label*="\u0111\xF3ng" i]'
    ];
    for (let attempt = 0; attempt < 3; attempt++) {
      for (const sel of closeSelectors) {
        const el = document.querySelector(sel);
        if (el && isVisible(el)) {
          humanClick(clickableAncestor(el));
          await sleep(280);
          if (!isModalOpen() && !onVideoRoute()) return;
        }
      }
      if (!isModalOpen() && !onVideoRoute()) return;
      pressEscape();
      await sleep(320);
      if (!isModalOpen() && !onVideoRoute()) return;
    }
    if (onVideoRoute() && window.history.length > 1) {
      try {
        window.history.back();
        const backDeadline = Date.now() + 2200;
        while (Date.now() < backDeadline) {
          await sleep(150);
          if (!onVideoRoute()) {
            if (!expectedProfileAccount || window.location.pathname.toLowerCase().includes(`/@${expectedProfileAccount.toLowerCase()}`)) {
              break;
            }
          }
        }
      } catch {
      }
    }
  }
  function findVideoCard(videoId) {
    const anchor = document.querySelector(
      `a[href*="/video/${videoId}"], a[href*="/photo/${videoId}"]`
    );
    if (!anchor) return null;
    return anchor;
  }
  function waitForNewGridAnchors(previousCount, timeoutMs = 1200) {
    const abortSignal = getActionAbortSignal();
    return new Promise((resolve) => {
      const countAnchors = () => document.querySelectorAll('a[href*="/video/"], a[href*="/photo/"]').length;
      if (abortSignal.aborted || countAnchors() > previousCount) {
        resolve(!abortSignal.aborted && countAnchors() > previousCount);
        return;
      }
      let settled = false;
      let observer = null;
      let timer = null;
      const cleanup = () => {
        if (settled) return;
        settled = true;
        observer?.disconnect();
        if (timer) clearTimeout(timer);
        abortSignal.removeEventListener("abort", onAbort);
      };
      const onAbort = () => {
        cleanup();
        resolve(false);
      };
      abortSignal.addEventListener("abort", onAbort, { once: true });
      try {
        observer = new MutationObserver(() => {
          if (countAnchors() > previousCount) {
            cleanup();
            resolve(true);
          }
        });
        observer.observe(document.body, { childList: true, subtree: true });
      } catch {
      }
      timer = setTimeout(() => {
        const grew = countAnchors() > previousCount;
        cleanup();
        resolve(grew);
      }, timeoutMs);
    });
  }
  async function scrollSearchDown(videoId, container, maxScrolls) {
    if (isActionAborted()) return null;
    let card = findVideoCard(videoId);
    if (card && isVisible(card)) return card;
    let lastPos = getScrollPosition(container);
    let stalledCount = 0;
    for (let i = 0; i < maxScrolls && !isActionAborted(); i++) {
      const prevAnchorCount = document.querySelectorAll('a[href*="/video/"], a[href*="/photo/"]').length;
      performScroll(container, Math.max(500, window.innerHeight * 1.25));
      if (!await sleepUnlessActionAborted(550)) return null;
      card = findVideoCard(videoId);
      if (card && isVisible(card)) return card;
      const currentPos = getScrollPosition(container);
      if (Math.abs(currentPos - lastPos) < 10) {
        const grew = await waitForNewGridAnchors(prevAnchorCount, 1200);
        if (isActionAborted()) return null;
        card = findVideoCard(videoId);
        if (card && isVisible(card)) return card;
        if (grew) {
          stalledCount = 0;
        } else {
          stalledCount += 1;
          if (stalledCount >= 2) {
            if (container === window) {
              window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "smooth" });
            } else {
              container.scrollTop = container.scrollHeight;
            }
            if (!await sleepUnlessActionAborted(850)) return null;
            card = findVideoCard(videoId);
            if (card && isVisible(card)) return card;
            if (stalledCount >= 3) break;
          }
        }
      } else {
        stalledCount = 0;
      }
      lastPos = currentPos;
    }
    return null;
  }
  async function locateAndScrollToCard(videoId, maxScrolls = 20) {
    if (isActionAborted()) return null;
    const existing = findVideoCard(videoId);
    if (existing && isVisible(existing)) return existing;
    const currentGrid = document.querySelector('[data-e2e*="item-list"], [role="tabpanel"], main') || document.body;
    const container = detectScrollContainer(currentGrid);
    const startPos = getScrollPosition(container);
    const foundDown = await scrollSearchDown(videoId, container, maxScrolls);
    if (foundDown || isActionAborted()) return foundDown;
    if (startPos > 350) {
      if (container === window) {
        window.scrollTo({ top: 0, behavior: "auto" });
      } else {
        container.scrollTop = 0;
      }
      if (!await sleepUnlessActionAborted(600)) return null;
      return scrollSearchDown(videoId, container, maxScrolls);
    }
    return null;
  }
  function clickWithoutFullPageNav(target) {
    const blockNativeNav = (e) => {
      e.preventDefault();
    };
    window.addEventListener("click", blockNativeNav, { capture: false });
    try {
      humanClick(target);
    } finally {
      window.removeEventListener("click", blockNativeNav, { capture: false });
    }
  }
  async function openVideoModal(card, expectedVideoId) {
    if (isActionAborted()) return false;
    if (isModalOpen()) {
      const curVid = extractVideoIdFromUrl(window.location.pathname);
      if (expectedVideoId && curVid === expectedVideoId) {
        return true;
      }
    }
    const previousSrc = currentViewerVideoSrc();
    const anchor = card.tagName.toLowerCase() === "a" ? card : card.closest("a");
    const innerTarget = card.querySelector(
      'canvas, video, img, [class*="PlayerContainer"], [class*="CardContainer"], [class*="DivWrapper"]'
    ) || anchor || card;
    clickWithoutFullPageNav(innerTarget);
    let opened = await waitForModal(4500, expectedVideoId, previousSrc);
    if (!opened && !isActionAborted() && anchor && anchor !== innerTarget) {
      clickWithoutFullPageNav(anchor);
      opened = await waitForModal(4e3, expectedVideoId, previousSrc);
    }
    return opened;
  }
  async function performActionOnProfile(action, videoId, account, url, options) {
    if (isActionAborted()) {
      return {
        status: "failed",
        code: "USER_ABORTED",
        stage: "FAILED",
        trace: ["OPENING", "FAILED"],
        message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng."
      };
    }
    const kind = action === "remove_repost" ? "repost" : "like";
    const cleanAccount = account.replace(/^@/, "");
    await closeModal(cleanAccount);
    if (isActionAborted()) {
      return {
        status: "failed",
        code: "USER_ABORTED",
        stage: "FAILED",
        trace: ["OPENING", "FAILED"],
        message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng."
      };
    }
    const tabRes = await openProfileTab(kind, cleanAccount, getActionAbortSignal());
    if (isActionAborted() || tabRes.error === "USER_ABORTED") {
      return {
        status: "failed",
        code: "USER_ABORTED",
        stage: "FAILED",
        trace: ["OPENING", "FAILED"],
        message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng."
      };
    }
    if (!tabRes.ok) {
      return {
        status: "failed",
        code: "TAB_ERROR",
        stage: "FAILED",
        trace: ["OPENING", "FAILED"],
        message: tabRes.error || `Kh\xF4ng th\u1EC3 m\u1EDF tab ${kind} tr\xEAn trang c\xE1 nh\xE2n`
      };
    }
    const scrollBudget = options?.maxScrolls ?? 20;
    let card = await locateAndScrollToCard(videoId, scrollBudget);
    if (!card && !isActionAborted() && scrollBudget > 0) {
      await waitForNewGridAnchors(
        document.querySelectorAll('a[href*="/video/"], a[href*="/photo/"]').length,
        1500
      );
      if (!isActionAborted()) {
        card = findVideoCard(videoId);
      }
    }
    if (isActionAborted()) {
      return {
        status: "failed",
        code: "USER_ABORTED",
        stage: "FAILED",
        trace: ["OPENING", "FAILED"],
        message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng."
      };
    }
    if (!card) {
      return {
        status: "unverified",
        code: "CARD_NOT_FOUND_ON_GRID",
        stage: "UNVERIFIED",
        trace: ["OPENING", "UNVERIFIED"],
        message: "Ch\u01B0a t\xECm th\u1EA5y th\u1EBB video tr\xEAn l\u01B0\u1EDBi trang c\xE1 nh\xE2n \u2014 chuy\u1EC3n sang ki\u1EC3m tra tr\u1EF1c ti\u1EBFp trang video \u0111\u1EC3 x\xE1c minh tr\u1EA1ng th\xE1i n\xFAt Tim."
      };
    }
    try {
      card.scrollIntoView({ block: "center", behavior: "instant" });
      if (!await sleepUnlessActionAborted(250)) {
        return {
          status: "failed",
          code: "USER_ABORTED",
          stage: "FAILED",
          trace: ["OPENING", "FAILED"],
          message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng."
        };
      }
    } catch {
    }
    const modalOpened = await openVideoModal(card, videoId);
    if (isActionAborted()) {
      await closeModal(cleanAccount);
      return {
        status: "failed",
        code: "USER_ABORTED",
        stage: "FAILED",
        trace: ["OPENING", "FAILED"],
        message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng."
      };
    }
    if (!modalOpened) {
      if (detectUnavailable()) {
        return {
          status: "unavailable",
          code: "VIDEO_UNAVAILABLE",
          stage: "FAILED",
          trace: ["OPENING", "FAILED"],
          message: "Video kh\xF4ng kh\u1EA3 d\u1EE5ng, ri\xEAng t\u01B0 ho\u1EB7c \u0111\xE3 b\u1ECB x\xF3a"
        };
      }
      return {
        status: "unverified",
        code: "MODAL_NOT_OPENED",
        stage: "UNVERIFIED",
        trace: ["OPENING", "UNVERIFIED"],
        message: "Ch\u01B0a m\u1EDF \u0111\u01B0\u1EE3c khung xem video tr\xEAn l\u01B0\u1EDBi \u2014 chuy\u1EC3n sang m\u1EDF tr\u1EF1c ti\u1EBFp tr\xEAn c\xF9ng tab."
      };
    }
    try {
      if (!await sleepUnlessActionAborted(180)) {
        return {
          status: "failed",
          code: "USER_ABORTED",
          stage: "FAILED",
          trace: ["OPENING", "FAILED"],
          message: "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng."
        };
      }
      const targetUrl = url || window.location.href;
      if (action === "remove_repost") {
        return await removeRepost(videoId, targetUrl, options);
      }
      return await removeLike(videoId, targetUrl, { initialTrace: ["OPENING"] });
    } finally {
      await closeModal(cleanAccount);
    }
  }
  async function executePerform(action, videoId, account, url, directVideoPage = false) {
    const targetUrl = url || window.location.href;
    const path = window.location.pathname.toLowerCase();
    const cleanAccount = account ? account.replace(/^@/, "").toLowerCase() : "";
    const onProfile = Boolean(cleanAccount && path.includes(`/@${cleanAccount}`));
    if (action === "remove_repost") {
      const apiRes = await removeRepost(videoId, targetUrl);
      if (apiRes.status === "success" || apiRes.haltRun) {
        return apiRes;
      }
      if (onProfile && apiRes.code === "API_REPOST_DELETE_FAILED") {
        return performActionOnProfile("remove_repost", videoId, account, url, { domOnly: true });
      }
      return apiRes;
    }
    const currentVideoId = extractVideoIdFromUrl(window.location.pathname);
    if (directVideoPage || currentVideoId === videoId && isModalOpen()) {
      return removeLike(videoId, targetUrl, { initialTrace: ["OPENING"] });
    }
    if (cleanAccount) {
      return performActionOnProfile("remove_like", videoId, account, url);
    }
    return removeLike(videoId, targetUrl, { initialTrace: ["OPENING"] });
  }
  (() => {
    if (window.__tiktokCleanerProLoaded) {
      return;
    }
    window.__tiktokCleanerProLoaded = true;
    try {
      chrome.runtime.sendMessage({
        type: "CONTENT_READY",
        url: window.location.href
      }).catch(() => {
      });
    } catch {
    }
    if (typeof chrome === "undefined" || !chrome.runtime?.onMessage) {
      return;
    }
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      switch (message.type) {
        case "PING": {
          const acc = detectAccount(document);
          const resp = {
            ok: true,
            url: window.location.href,
            account: {
              ...acc,
              checkedAt: Date.now(),
              tabId: null
            },
            captcha: detectCaptcha(document),
            http403: detectHttp403(document)
          };
          sendResponse(resp);
          return false;
        }
        case "DETECT_ACCOUNT": {
          const acc = detectAccount(document);
          sendResponse({
            ok: true,
            account: {
              ...acc,
              checkedAt: Date.now(),
              tabId: null
            }
          });
          return false;
        }
        case "SCAN_STOP": {
          stopScanning();
          sendResponse({ ok: true });
          return false;
        }
        case "ACTION_STOP": {
          abortAction();
          sendResponse({ ok: true });
          return false;
        }
        case "START_SCAN_TAB": {
          sendResponse({ ok: true, started: true });
          runScan(
            message.kind,
            message.username,
            message.limit,
            message.knownIds,
            message.secUid,
            Boolean(message.skipApi)
          ).catch((err) => {
            chrome.runtime.sendMessage({
              type: "SCAN_DONE",
              kind: message.kind,
              total: 0,
              code: "SCAN_ERROR",
              message: err instanceof Error ? err.message : String(err)
            }).catch(() => {
            });
          });
          return false;
        }
        case "SCAN": {
          runScan(
            message.kind,
            message.username,
            message.limit,
            message.knownIds,
            message.secUid,
            Boolean(message.skipApi)
          ).then((result) => sendResponse(result)).catch((err) => {
            sendResponse({
              ok: false,
              code: "SCAN_EXCEPTION",
              message: err instanceof Error ? err.message : String(err),
              total: 0
            });
          });
          return true;
        }
        case "VERIFY_REPOSTS": {
          resetActionAbort();
          verifyRepostsViaApi(message.secUid, "", message.pageLimit, isActionAborted).then((res) => sendResponse(res)).catch((err) => {
            const code = err instanceof SafetyStopError ? err.code : "VERIFY_ERROR";
            sendResponse({
              ok: false,
              code,
              error: err instanceof Error ? err.message : String(err),
              presentIds: []
            });
          });
          return true;
        }
        case "PERFORM": {
          resetActionAbort();
          executePerform(
            message.action,
            message.videoId,
            message.account,
            message.url,
            Boolean(message.directVideoPage)
          ).then((res) => sendResponse(res)).catch((err) => {
            sendResponse({
              status: "failed",
              code: "ACTION_EXCEPTION",
              message: err instanceof Error ? err.message : String(err)
            });
          });
          return true;
        }
        default:
          return false;
      }
    });
  })();
})();
