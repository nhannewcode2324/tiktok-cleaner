// src/shared/constants.ts
var DEFAULT_SETTINGS = {
  language: "vi",
  theme: "dark",
  actionDelay: 2,
  maxItemsPerRun: 2e3,
  retryLimit: 1,
  stopOnConsecutiveErrors: 5,
  confirmBeforeCleanup: true,
  scanLimit: 2e3
};
var SETTINGS_LIMITS = {
  actionDelay: { min: 1, max: 30 },
  maxItemsPerRun: { min: 1, max: 5e3 },
  retryLimit: { min: 0, max: 3 },
  stopOnConsecutiveErrors: { min: 1, max: 20 },
  scanLimit: { min: 20, max: 1e4 }
};
var TIKTOK_ORIGIN = "https://www.tiktok.com";
var TIKTOK_MATCH_PATTERNS = ["https://www.tiktok.com/*", "https://tiktok.com/*", "https://*.tiktok.com/*"];
var LOG_LIMIT = 3e3;
var HISTORY_LIMIT = 100;
var HALT_CODES = /* @__PURE__ */ new Set([
  "CAPTCHA",
  "RATE_LIMIT",
  "NOT_LOGGED_IN",
  "ACCOUNT_MISMATCH",
  "TAB_CLOSED",
  "OFFLINE",
  "HTTP_401",
  "HTTP_403",
  "HTTP_429",
  "ACCESS_DENIED",
  "SAFETY_STOP",
  "WRONG_FEED_GUARD",
  "LIKED_TAB_DESELECTED",
  "VERIFY_STREAK",
  "VERIFY_WINDOW",
  "VERIFY_CEILING",
  "INDETERMINATE_DOM"
]);
function clampSettings(input, base = DEFAULT_SETTINGS) {
  const s = { ...base, ...input, confirmBeforeCleanup: true };
  const clamp = (v, k, fallback) => {
    const n = Number(v);
    const { min, max } = SETTINGS_LIMITS[k];
    if (!Number.isFinite(n)) return fallback;
    return Math.min(max, Math.max(min, Math.round(n)));
  };
  s.actionDelay = clamp(s.actionDelay, "actionDelay", base.actionDelay);
  s.maxItemsPerRun = clamp(s.maxItemsPerRun, "maxItemsPerRun", base.maxItemsPerRun);
  s.retryLimit = clamp(s.retryLimit, "retryLimit", base.retryLimit);
  s.stopOnConsecutiveErrors = clamp(s.stopOnConsecutiveErrors, "stopOnConsecutiveErrors", base.stopOnConsecutiveErrors);
  s.scanLimit = clamp(s.scanLimit, "scanLimit", base.scanLimit);
  if (s.language !== "en" && s.language !== "vi") s.language = base.language;
  if (s.theme !== "dark" && s.theme !== "light") s.theme = base.theme;
  return s;
}

// src/services/automation-queue.ts
var NO_AUTO_RETRY_CODES = /* @__PURE__ */ new Set([
  "VERIFY_FAILED",
  "VERIFY_INDETERMINATE",
  "INDETERMINATE_LIKE_STATE",
  "INDETERMINATE_BEFORE_CLICK",
  "VIDEO_ID_MISMATCH"
]);
var TRACKER_WINDOW_SIZE = 10;
var VERIFY_FAIL_STREAK_LIMIT = 2;
var VERIFY_FAIL_WINDOW_LIMIT = 3;
var VERIFY_FAIL_TOTAL_CEILING = 10;
var DET_FAIL_STREAK_LIMIT = 4;
var DET_FAIL_WINDOW_LIMIT = 6;
function emptyQueue() {
  return {
    runId: null,
    account: null,
    status: "idle",
    reasonCode: null,
    reason: null,
    jobs: [],
    createdAt: null,
    startedAt: null,
    finishedAt: null,
    consecutiveErrors: 0,
    workerTabId: null,
    verifyHistory: [],
    verifyStreak: 0,
    verifyFailsTotal: 0,
    detHistory: [],
    detStreak: 0
  };
}
function actionFor(kind) {
  return kind === "repost" ? "remove_repost" : "remove_like";
}
function isActive(q) {
  return q.status === "running" || q.status === "pausing";
}
function createQueue(videos, account, maxItems, runId, now) {
  const seen = /* @__PURE__ */ new Set();
  const jobs = [];
  const sortedVideos = [...videos].sort((a, b) => {
    if (a.kind === b.kind) return a.scanIndex - b.scanIndex;
    return a.kind === "repost" ? -1 : 1;
  });
  for (const v of sortedVideos) {
    if (seen.has(v.key)) continue;
    seen.add(v.key);
    if (jobs.length >= maxItems) break;
    jobs.push({
      key: v.key,
      videoId: v.videoId,
      accountId: account,
      url: v.url,
      action: actionFor(v.kind),
      attempts: 0,
      status: "pending",
      error: null,
      errorCode: null,
      processedAt: null
    });
  }
  return {
    ...emptyQueue(),
    runId,
    account,
    status: "running",
    jobs,
    createdAt: now,
    startedAt: now
  };
}
function nextPendingIndex(q) {
  let best = -1;
  for (let i = 0; i < q.jobs.length; i++) {
    const j = q.jobs[i];
    if (j.status !== "pending") continue;
    if (best === -1 || j.attempts < q.jobs[best].attempts) best = i;
  }
  return best;
}
function markProcessing(q, index) {
  const jobs = q.jobs.slice();
  jobs[index] = { ...jobs[index], status: "processing", attempts: jobs[index].attempts + 1 };
  return { ...q, jobs };
}
function applyResult(q, index, result, opts) {
  const jobs = q.jobs.slice();
  const job = { ...jobs[index] };
  let next = { ...q };
  let halted = false;
  if ((result.status === "failed" || result.status === "unverified") && (result.haltRun || HALT_CODES.has(result.code))) {
    job.status = "pending";
    job.attempts = Math.max(0, job.attempts - 1);
    job.error = result.message;
    job.errorCode = result.code;
    jobs[index] = job;
    next = { ...next, jobs, status: "paused", reasonCode: result.code, reason: result.message };
    return { queue: next, halted: true };
  }
  job.error = result.status === "success" ? null : result.message;
  job.errorCode = result.status === "success" ? null : result.code;
  if (result.status === "failed" || result.status === "unverified") {
    const noAutoRetry = NO_AUTO_RETRY_CODES.has(result.code);
    const maxAttempts = noAutoRetry ? 1 : 1 + Math.max(0, opts.retryLimit);
    if (job.attempts >= maxAttempts) {
      job.status = result.status;
      job.processedAt = opts.now;
    } else {
      job.status = "pending";
    }
    next.consecutiveErrors = q.consecutiveErrors + 1;
  } else {
    job.status = result.status;
    job.processedAt = opts.now;
    if (result.status !== "unavailable") next.consecutiveErrors = 0;
  }
  jobs[index] = job;
  next.jobs = jobs;
  if (job.action === "remove_like") {
    const detHist = [...q.detHistory ?? []];
    let detStreak = q.detStreak ?? 0;
    if (result.code === "INDETERMINATE_LIKE_STATE" || result.code === "INDETERMINATE_BEFORE_CLICK") {
      detHist.push(false);
      if (detHist.length > TRACKER_WINDOW_SIZE) detHist.shift();
      detStreak += 1;
      next.detHistory = detHist;
      next.detStreak = detStreak;
      const detWindowFails = detHist.filter((ok) => !ok).length;
      if (detStreak >= DET_FAIL_STREAK_LIMIT || detHist.length >= DET_FAIL_WINDOW_LIMIT && detWindowFails >= DET_FAIL_WINDOW_LIMIT) {
        next.status = "paused";
        next.reasonCode = "INDETERMINATE_DOM";
        next.reason = "T\u1EA1m d\u1EEBng an to\xE0n: Kh\xF4ng x\xE1c \u0111\u1ECBnh \u0111\u01B0\u1EE3c tr\u1EA1ng th\xE1i n\xFAt Tim nhi\u1EC1u l\u1EA7n li\xEAn ti\u1EBFp (DOM TikTok ch\u01B0a t\u1EA3i \u0111\u1EE7 ho\u1EB7c \u0111\xE3 thay \u0111\u1ED5i).";
        halted = true;
      }
    } else if (result.status === "success" || result.code === "ALREADY_UNLIKED" || result.code === "VERIFY_FAILED" || result.code === "VERIFY_INDETERMINATE") {
      detHist.push(true);
      if (detHist.length > TRACKER_WINDOW_SIZE) detHist.shift();
      next.detHistory = detHist;
      next.detStreak = 0;
    }
    const verHist = [...q.verifyHistory ?? []];
    let verStreak = q.verifyStreak ?? 0;
    let verTotal = q.verifyFailsTotal ?? 0;
    if (result.status === "success") {
      verHist.push(true);
      if (verHist.length > TRACKER_WINDOW_SIZE) verHist.shift();
      next.verifyHistory = verHist;
      next.verifyStreak = 0;
    } else if (result.code === "VERIFY_FAILED" || result.code === "VERIFY_INDETERMINATE") {
      verHist.push(false);
      if (verHist.length > TRACKER_WINDOW_SIZE) verHist.shift();
      verStreak += 1;
      verTotal += 1;
      next.verifyHistory = verHist;
      next.verifyStreak = verStreak;
      next.verifyFailsTotal = verTotal;
      const verWindowFails = verHist.filter((ok) => !ok).length;
      if (verStreak >= VERIFY_FAIL_STREAK_LIMIT) {
        next.status = "paused";
        next.reasonCode = "VERIFY_STREAK";
        next.reason = "T\u1EA1m d\u1EEBng an to\xE0n: 2 l\u1EA7n b\u1ECF tim li\xEAn ti\u1EBFp ch\u01B0a x\xE1c minh \u0111\u01B0\u1EE3c tr\u1EA1ng th\xE1i (TikTok c\xF3 th\u1EC3 \u0111ang gi\u1EDBi h\u1EA1n t\u1ED1c \u0111\u1ED9 ng\u1EA7m).";
        halted = true;
      } else if (verWindowFails >= VERIFY_FAIL_WINDOW_LIMIT) {
        next.status = "paused";
        next.reasonCode = "VERIFY_WINDOW";
        next.reason = "T\u1EA1m d\u1EEBng an to\xE0n: C\xF3 t\u1EEB 3/10 l\u1EA7n b\u1ECF tim g\u1EA7n nh\u1EA5t kh\xF4ng x\xE1c minh \u0111\u01B0\u1EE3c tr\u1EA1ng th\xE1i.";
        halted = true;
      } else if (verTotal >= VERIFY_FAIL_TOTAL_CEILING) {
        next.status = "paused";
        next.reasonCode = "VERIFY_CEILING";
        next.reason = "T\u1EA1m d\u1EEBng an to\xE0n: \u0110\xE3 ch\u1EA1m ng\u01B0\u1EE1ng 10 l\u1EA7n kh\xF4ng x\xE1c minh \u0111\u01B0\u1EE3c b\u1ECF tim trong phi\xEAn n\xE0y.";
        halted = true;
      }
    }
  }
  if (!halted && next.consecutiveErrors >= opts.stopOnConsecutiveErrors) {
    next.status = "paused";
    next.reasonCode = "TOO_MANY_ERRORS";
    next.reason = `Paused after ${next.consecutiveErrors} consecutive errors`;
    halted = true;
  }
  return { queue: next, halted };
}
function requestPause(q) {
  if (q.status === "running") return { ...q, status: "pausing", reasonCode: "USER_PAUSE", reason: "Paused by user" };
  return q;
}
function settlePause(q) {
  if (q.status === "pausing") return { ...q, status: "paused" };
  return q;
}
function canResume(q) {
  return (q.status === "paused" || q.status === "pausing" || q.status === "stopped") && nextPendingIndex(q) !== -1;
}
function resume(q) {
  if (!canResume(q)) return q;
  const jobs = q.jobs.map(
    (j) => j.status === "processing" ? { ...j, status: "pending", attempts: Math.max(0, j.attempts - 1) } : j
  );
  return {
    ...q,
    jobs,
    status: "running",
    reasonCode: null,
    reason: null,
    finishedAt: null,
    consecutiveErrors: 0,
    verifyStreak: 0,
    detStreak: 0,
    verifyHistory: [],
    detHistory: [],
    verifyFailsTotal: q.reasonCode === "VERIFY_CEILING" ? 0 : q.verifyFailsTotal ?? 0
  };
}
function stop(q, now, reason = "\u0110\xE3 d\u1EEBng d\u1ECDn d\u1EB9p; ti\u1EBFn \u0111\u1ED9 \u0111\xE3 \u0111\u01B0\u1EE3c l\u01B0u.", code = "STOPPED") {
  if (q.status === "idle" || q.status === "completed" || q.status === "stopped") return q;
  const jobs = q.jobs.map(
    (j) => j.status === "processing" ? { ...j, status: "pending", attempts: Math.max(0, j.attempts - 1) } : j
  );
  return { ...q, jobs, status: "stopped", reasonCode: code, reason, finishedAt: now };
}
function complete(q, now) {
  return { ...q, status: "completed", finishedAt: now, reasonCode: null, reason: null };
}
function recoverAfterRestart(q) {
  if (!isActive(q) && !q.jobs.some((j) => j.status === "processing")) return q;
  const jobs = q.jobs.map(
    (j) => j.status === "processing" ? { ...j, status: "pending", attempts: Math.max(0, j.attempts - 1) } : j
  );
  const status = isActive(q) ? "paused" : q.status;
  return {
    ...q,
    jobs,
    status,
    reasonCode: isActive(q) ? "INTERRUPTED" : q.reasonCode,
    reason: isActive(q) ? "Interrupted (extension restarted). Review and press Resume to continue." : q.reason
  };
}
function summarize(q) {
  const s = {
    total: q.jobs.length,
    processed: 0,
    success: 0,
    failed: 0,
    unverified: 0,
    skipped: 0,
    unavailable: 0,
    pending: 0,
    processing: 0,
    percent: 0
  };
  for (const j of q.jobs) {
    if (j.status === "pending") s.pending++;
    else if (j.status === "processing") s.processing++;
    else {
      s.processed++;
      if (j.status === "success") s.success++;
      else if (j.status === "failed") s.failed++;
      else if (j.status === "unverified") s.unverified++;
      else if (j.status === "skipped") s.skipped++;
      else if (j.status === "unavailable") s.unavailable++;
    }
  }
  s.percent = s.total ? Math.round(s.processed / s.total * 100) : 0;
  return s;
}

// src/shared/utils.ts
function uid(prefix = "") {
  return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function videoKey(kind, videoId) {
  return `${kind}:${videoId}`;
}

// src/services/selection-manager.ts
function isEligible(v, results) {
  const r = results[v.key];
  if (!r) return true;
  return r.status !== "success" && r.status !== "unavailable" && r.status !== "skipped";
}

// src/services/storage-manager.ts
var K = {
  settings: "settings",
  uiPrefs: "uiPrefs",
  account: "account",
  queue: "queue",
  scan: "scan",
  log: "log",
  history: "history",
  videos: (acct) => `videos:${acct.toLowerCase()}`,
  selection: (acct) => `selection:${acct.toLowerCase()}`,
  results: (acct) => `results:${acct.toLowerCase()}`
};
var emptyScan = () => ({
  status: "idle",
  account: null,
  kinds: [],
  currentKind: null,
  found: 0,
  newFound: 0,
  message: null,
  code: null,
  startedAt: null,
  finishedAt: null
});
async function get(key, fallback) {
  const r = await chrome.storage.local.get(key);
  return r[key] ?? fallback;
}
async function set(key, value) {
  await chrome.storage.local.set({ [key]: value });
}
var storage = {
  get,
  set,
  async getSettings() {
    return clampSettings(await get(K.settings, DEFAULT_SETTINGS));
  },
  async saveSettings(s) {
    const cur = await storage.getSettings();
    const next = clampSettings({ ...cur, ...s });
    await set(K.settings, next);
    return next;
  },
  getAccount: () => get(K.account, null),
  setAccount: (a) => set(K.account, a),
  getUiPrefs: async () => {
    const raw = await get(K.uiPrefs, { filter: "all", sort: "newest" });
    const validSorts = /* @__PURE__ */ new Set(["newest", "oldest", "post_newest", "views_desc", "views_asc", "author_asc"]);
    const sort = raw.sort && validSorts.has(raw.sort) ? raw.sort : "newest";
    return {
      filter: raw.filter || "all",
      sort
    };
  },
  setUiPrefs: (prefs) => storage.getUiPrefs().then((cur) => set(K.uiPrefs, { ...cur, ...prefs })),
  getQueue: () => get(K.queue, emptyQueue()),
  setQueue: (q) => set(K.queue, q),
  getScan: () => get(K.scan, emptyScan()),
  setScan: (s) => set(K.scan, s),
  getVideos: async (acct) => {
    return get(K.videos(acct), []);
  },
  setVideos: (acct, v) => set(K.videos(acct), v),
  getSelection: async (acct) => new Set(await get(K.selection(acct), [])),
  setSelection: (acct, sel) => set(K.selection(acct), [...sel]),
  getResults: (acct) => get(K.results(acct), {}),
  setResults: (acct, r) => set(K.results(acct), r),
  getLog: () => get(K.log, []),
  async appendLog(entries) {
    const arr = Array.isArray(entries) ? entries : [entries];
    const log = await storage.getLog();
    const now = Date.now();
    for (const e of arr) log.push({ ...e, id: uid("l"), ts: now });
    await set(K.log, log.length > LOG_LIMIT ? log.slice(log.length - LOG_LIMIT) : log);
  },
  getHistory: () => get(K.history, []),
  async addHistory(h) {
    const list = (await storage.getHistory()).filter((x) => x.runId !== h.runId);
    list.unshift(h);
    await set(K.history, list.slice(0, HISTORY_LIMIT));
  },
  /** Remove everything except settings. */
  async clearAll() {
    const settings = await storage.getSettings();
    await chrome.storage.local.clear();
    await set(K.settings, settings);
  }
};

// src/background/service-worker.ts
var isLoopRunning = false;
var queueStopRequested = false;
var queuePauseRequested = false;
var activeQueueRunToken = 0;
var scanStopRequested = false;
var activeScanRunToken = 0;
var activeScanTabId = null;
var storageMutex = Promise.resolve();
function withStorageLock(fn) {
  const next = storageMutex.then(fn, fn);
  storageMutex = next.then(
    () => void 0,
    () => void 0
  );
  return next;
}
function randomBetween(min, max) {
  return Math.floor(min + Math.random() * (max - min + 1));
}
async function broadcastToTikTokTabs(msg, extraTabId) {
  const sent = /* @__PURE__ */ new Set();
  if (typeof extraTabId === "number") {
    sent.add(extraTabId);
    chrome.tabs.sendMessage(extraTabId, msg).catch(() => {
    });
  }
  try {
    const tabs = await chrome.tabs.query({ url: TIKTOK_MATCH_PATTERNS });
    for (const t of tabs) {
      if (t.id !== void 0 && !sent.has(t.id)) {
        sent.add(t.id);
        chrome.tabs.sendMessage(t.id, msg).catch(() => {
        });
      }
    }
  } catch {
  }
}
async function interruptibleSleep(ms, runToken) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (queueStopRequested || queuePauseRequested || activeQueueRunToken !== runToken) break;
    await sleep(Math.min(100, end - Date.now()));
    if (queueStopRequested || queuePauseRequested || activeQueueRunToken !== runToken) break;
    const q = await storage.getQueue();
    if (q.status !== "running") break;
  }
}
chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {
    });
  }
  storage.getQueue().then((q) => {
    const recovered = recoverAfterRestart(q);
    if (recovered.status !== q.status || recovered.jobs.some((j, i) => j.status !== q.jobs[i]?.status)) {
      storage.setQueue(recovered);
      storage.appendLog({
        level: "warn",
        message: "\u0110\xE3 kh\xF4i ph\u1EE5c h\xE0ng \u0111\u1EE3i sau khi t\u1EA3i l\u1EA1i ti\u1EC7n \xEDch (T\u1EA1m d\u1EEBng an to\xE0n)."
      });
    }
  });
});
chrome.runtime.onStartup.addListener(async () => {
  try {
    const acc = await storage.getAccount();
    if (acc?.username) {
      await storage.setVideos(acc.username, []);
      await storage.setSelection(acc.username, /* @__PURE__ */ new Set());
      await storage.setResults(acc.username, {});
    }
    await storage.setQueue(emptyQueue());
    await storage.setScan(emptyScan());
    await storage.appendLog({
      level: "info",
      message: "Kh\u1EDFi \u0111\u1ED9ng tr\xECnh duy\u1EC7t: \u0110\xE3 t\u1EF1 \u0111\u1ED9ng \u0111\u1EB7t l\u1EA1i to\xE0n b\u1ED9 d\u1EEF li\u1EC7u v\u1EC1 0."
    });
  } catch {
  }
});
function readTikTokPageSessionInMainWorld() {
  try {
    const title = (document.title || "").toLowerCase();
    const bodyText = (document.body?.innerText || "").slice(0, 600).toLowerCase();
    const http403 = title.includes("403 forbidden") || title.includes("access denied") || bodyText.includes("http error 403") && bodyText.includes("denied") || bodyText.includes("access to") && bodyText.includes("was denied") && bodyText.includes("tiktok.com");
    const win = window;
    let user = win.__$UNIVERSAL_DATA$__?.__DEFAULT_SCOPE__?.["webapp.app-context"]?.user;
    if (!user?.secUid && !user?.uniqueId) {
      const scriptEl = document.getElementById("__UNIVERSAL_DATA_FOR_REHYDRATION__");
      if (scriptEl?.textContent) {
        try {
          const parsed = JSON.parse(scriptEl.textContent);
          user = parsed?.__DEFAULT_SCOPE__?.["webapp.app-context"]?.user;
        } catch {
        }
      }
    }
    if (!user?.secUid && !user?.uniqueId) {
      user = win.SIGI_STATE?.AppContext?.appContext?.user;
    }
    const username = user?.uniqueId ? String(user.uniqueId).replace(/^@/, "").trim() : null;
    const secUid = user?.secUid ? String(user.secUid).trim() : null;
    const userId = user?.uid ? String(user.uid).trim() : null;
    return {
      loggedIn: Boolean(username || secUid),
      username: username || null,
      secUid: secUid || null,
      uid: userId || null,
      http403
    };
  } catch {
    return {
      loggedIn: false,
      username: null,
      secUid: null,
      uid: null,
      http403: false
    };
  }
}
async function getPageSessionFromMainWorld(tabId) {
  try {
    if (!chrome.scripting?.executeScript) return null;
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: readTikTokPageSessionInMainWorld
    });
    return results?.[0]?.result ?? null;
  } catch {
    return null;
  }
}
async function executeMainWorldFetch(tabId, req) {
  try {
    if (!chrome.scripting?.executeScript) {
      return { ok: false, status: 0, data: null, networkError: "Scripting API unavailable" };
    }
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      args: [req.pathAndQuery, req.method, req.body ?? null, req.headers ?? null, req.timeoutMs],
      func: async (pathAndQuery, method, body, headers, timeoutMs) => {
        const controller = new AbortController();
        const timer = window.setTimeout(() => controller.abort(), timeoutMs);
        try {
          const url = pathAndQuery.startsWith("http") ? pathAndQuery : `${window.location.origin}${pathAndQuery.startsWith("/") ? "" : "/"}${pathAndQuery}`;
          const init = {
            method,
            credentials: "include",
            signal: controller.signal
          };
          if (headers) init.headers = headers;
          if (body !== null && method !== "GET") init.body = body;
          const response = await window.fetch(url, init);
          const text = await response.text();
          let data = null;
          if (text) {
            try {
              data = JSON.parse(text);
            } catch {
              data = null;
            }
          }
          return {
            ok: response.ok,
            status: response.status,
            data
          };
        } catch (err) {
          const timedOut = err instanceof DOMException && err.name === "AbortError";
          return {
            ok: false,
            status: 0,
            data: null,
            timedOut,
            networkError: err instanceof Error ? err.message : String(err)
          };
        } finally {
          window.clearTimeout(timer);
        }
      }
    });
    return results?.[0]?.result ?? {
      ok: false,
      status: 0,
      data: null,
      networkError: "Empty script result"
    };
  } catch (err) {
    return {
      ok: false,
      status: 0,
      data: null,
      networkError: err instanceof Error ? err.message : String(err)
    };
  }
}
async function findTikTokTab() {
  const tabs = await chrome.tabs.query({ url: TIKTOK_MATCH_PATTERNS });
  if (tabs.length === 0) return null;
  const active = tabs.find((t) => t.active && t.id !== void 0);
  return active || tabs.find((t) => t.id !== void 0) || null;
}
function sameTikTokPath(a, b) {
  try {
    const pa = new URL(a || "").pathname.replace(/\/+$/, "").toLowerCase();
    const pb = new URL(b || "").pathname.replace(/\/+$/, "").toLowerCase();
    return pa === pb;
  } catch {
    return false;
  }
}
async function ensureTikTokTab(targetUrl) {
  const tab = await findTikTokTab();
  if (tab && tab.id !== void 0) {
    if (targetUrl && !sameTikTokPath(tab.url, targetUrl)) {
      return chrome.tabs.update(tab.id, { url: targetUrl, active: true });
    }
    return chrome.tabs.update(tab.id, { active: true });
  }
  return chrome.tabs.create({ url: targetUrl || `${TIKTOK_ORIGIN}/`, active: true });
}
async function waitForTabComplete(tabId, timeoutMs = 12e3) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const t = await chrome.tabs.get(tabId);
      if (t.status === "complete" && t.url && t.url.includes("tiktok.com")) {
        return true;
      }
    } catch {
      return false;
    }
    await sleep(300);
  }
  return false;
}
async function pingTab(tabId) {
  try {
    const res = await chrome.tabs.sendMessage(tabId, { type: "PING" });
    if (res && res.ok) return res;
  } catch {
    try {
      if (chrome.scripting?.executeScript) {
        await chrome.scripting.executeScript({
          target: { tabId },
          files: ["content.js"]
        });
        await sleep(300);
        const res2 = await chrome.tabs.sendMessage(tabId, { type: "PING" });
        if (res2 && res2.ok) return res2;
      }
    } catch {
    }
  }
  return null;
}
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url && tab.url.includes("tiktok.com")) {
    checkAccount(tabId).catch(() => {
    });
  }
});
async function checkAccount(tabId) {
  let targetTabId = tabId;
  if (!targetTabId) {
    const tab = await findTikTokTab();
    targetTabId = tab?.id;
  }
  if (!targetTabId) {
    const cached2 = await storage.getAccount();
    if (cached2) return { ...cached2, tabId: null };
    return { loggedIn: false, username: null, secUid: null, source: "none", checkedAt: Date.now(), tabId: null };
  }
  const mainSession = await getPageSessionFromMainWorld(targetTabId);
  if (mainSession && mainSession.loggedIn && mainSession.username) {
    const acc = {
      loggedIn: true,
      username: mainSession.username,
      secUid: mainSession.secUid,
      source: "main",
      checkedAt: Date.now(),
      tabId: targetTabId
    };
    await storage.setAccount(acc);
    return acc;
  }
  const ping = await pingTab(targetTabId);
  if (ping && ping.account && ping.account.loggedIn && ping.account.username) {
    const cached2 = await storage.getAccount();
    const preservedSecUid = mainSession?.secUid || (cached2?.username?.toLowerCase() === ping.account.username.toLowerCase() ? cached2.secUid : null) || null;
    const acc = {
      ...ping.account,
      secUid: preservedSecUid,
      tabId: targetTabId,
      checkedAt: Date.now()
    };
    await storage.setAccount(acc);
    return acc;
  }
  const cached = await storage.getAccount();
  if (cached && cached.loggedIn && cached.username && mainSession === null) {
    return { ...cached, tabId: targetTabId };
  }
  const disconnected = {
    loggedIn: false,
    username: null,
    secUid: null,
    source: "none",
    checkedAt: Date.now(),
    tabId: targetTabId
  };
  await storage.setAccount(disconnected);
  return disconnected;
}
async function navigateAndWaitForProfile(tabId, username, timeoutMs = 15e3, shouldAbort) {
  const cleanUsername = username.replace(/^@/, "");
  const profileUrl = `${TIKTOK_ORIGIN}/@${cleanUsername}`;
  const targetSubstr = `/@${cleanUsername.toLowerCase()}`;
  try {
    if (shouldAbort?.()) return { ok: false, aborted: true };
    const curTab = await chrome.tabs.get(tabId);
    const curUrl = (curTab.url || "").toLowerCase();
    if (curUrl.includes(targetSubstr)) {
      for (let i = 0; i < 10; i++) {
        if (shouldAbort?.()) return { ok: false, aborted: true };
        const ping = await pingTab(tabId);
        if (ping?.http403) return { ok: false, http403: true };
        if (ping?.ok) return { ok: true };
        await sleep(300);
      }
      return { ok: true };
    }
    await chrome.tabs.update(tabId, { url: profileUrl, active: true });
    const startTime = Date.now();
    while (Date.now() - startTime < timeoutMs) {
      if (shouldAbort?.()) return { ok: false, aborted: true };
      await sleep(300);
      if (shouldAbort?.()) return { ok: false, aborted: true };
      try {
        const t = await chrome.tabs.get(tabId);
        const url = (t.url || "").toLowerCase();
        if (url.includes("tiktok.com") && t.status === "complete") {
          const ping = await pingTab(tabId);
          if (ping?.http403) {
            return { ok: false, http403: true };
          }
          if (url.includes(targetSubstr) && ping?.ok) {
            await sleep(400);
            return shouldAbort?.() ? { ok: false, aborted: true } : { ok: true };
          }
        }
      } catch {
      }
    }
  } catch {
  }
  return shouldAbort?.() ? { ok: false, aborted: true } : { ok: false };
}
async function navigateAndWaitForDirectVideo(tabId, videoUrl, videoId, timeoutMs = 15e3, shouldAbort) {
  try {
    if (shouldAbort?.()) return { ok: false, aborted: true };
    await chrome.tabs.update(tabId, { url: videoUrl });
    const startTime = Date.now();
    while (Date.now() - startTime < timeoutMs) {
      if (shouldAbort?.()) return { ok: false, aborted: true };
      await sleep(300);
      if (shouldAbort?.()) return { ok: false, aborted: true };
      try {
        const t = await chrome.tabs.get(tabId);
        const url = t.url || "";
        if (url.includes("tiktok.com") && t.status === "complete") {
          const ping = await pingTab(tabId);
          if (ping?.http403) return { ok: false, http403: true };
          if (ping?.captcha) return { ok: false, captcha: true };
          if (ping?.ok && url.includes(videoId)) {
            await sleep(350);
            return shouldAbort?.() ? { ok: false, aborted: true } : { ok: true };
          }
        }
      } catch {
      }
    }
  } catch {
  }
  return shouldAbort?.() ? { ok: false, aborted: true } : { ok: false };
}
async function revertJobToPending(jobIdx, reasonCode, reason) {
  await withStorageLock(async () => {
    const q = await storage.getQueue();
    const jobs = q.jobs.map(
      (j, idx) => idx === jobIdx && j.status === "processing" ? { ...j, status: "pending", attempts: Math.max(0, j.attempts - 1) } : j
    );
    const preserveStopped = q.status === "stopped" || queueStopRequested;
    await storage.setQueue({
      ...q,
      status: preserveStopped ? "stopped" : "paused",
      reasonCode: preserveStopped ? q.reasonCode || "STOPPED" : reasonCode,
      reason: preserveStopped ? q.reason || "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng." : reason,
      jobs
    });
  });
}
async function settleUserInterrupt(jobIdx) {
  await withStorageLock(async () => {
    let q = await storage.getQueue();
    const jobs = q.jobs.map(
      (j, idx) => (jobIdx === void 0 || idx === jobIdx) && j.status === "processing" ? { ...j, status: "pending", attempts: Math.max(0, j.attempts - 1) } : j
    );
    q = { ...q, jobs };
    if (queueStopRequested || q.status === "stopped") {
      q = {
        ...q,
        status: "stopped",
        reasonCode: q.reasonCode || "STOPPED",
        reason: q.reason || "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng (ti\u1EBFn \u0111\u1ED9 \u0111\u01B0\u1EE3c gi\u1EEF nguy\xEAn)",
        finishedAt: q.finishedAt || Date.now()
      };
    } else if (queuePauseRequested || q.status === "pausing" || q.status === "paused") {
      q = {
        ...settlePause(q),
        status: "paused",
        reasonCode: q.reasonCode || "USER_PAUSE",
        reason: q.reason || "\u0110\xE3 t\u1EA1m d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng."
      };
    }
    await storage.setQueue(q);
  });
}
async function verifyRemovedRepostsOnServer(tabId, account, secUid) {
  if (queueStopRequested || queuePauseRequested) return;
  const queue = await storage.getQueue();
  const succeededRepostJobs = queue.jobs.filter(
    (j) => j.action === "remove_repost" && j.status === "success"
  );
  if (succeededRepostJobs.length === 0) return;
  const videos = await storage.getVideos(account);
  const videoByKey = new Map(videos.map((v) => [v.key, v]));
  let maxScanPage = 1;
  for (const job of succeededRepostJobs) {
    const v = videoByKey.get(job.key);
    if (v?.scanPage && v.scanPage > maxScanPage) {
      maxScanPage = v.scanPage;
    }
  }
  const pageLimit = Math.max(1, Math.min(maxScanPage, 15));
  await storage.appendLog({
    level: "info",
    message: `\u0110ang x\xE1c minh k\u1EBFt qu\u1EA3 x\xF3a Repost v\u1EDBi m\xE1y ch\u1EE7 TikTok (t\u1ED1i \u0111a ${pageLimit} trang)...`,
    account
  });
  try {
    const verifyRes = await chrome.tabs.sendMessage(tabId, {
      type: "VERIFY_REPOSTS",
      secUid,
      pageLimit
    });
    if (queueStopRequested || queuePauseRequested) return;
    if (!verifyRes?.ok || !Array.isArray(verifyRes.presentIds)) return;
    const stillPresent = new Set(verifyRes.presentIds);
    const failedVerifyKeys = /* @__PURE__ */ new Set();
    for (const job of succeededRepostJobs) {
      if (stillPresent.has(job.videoId)) {
        failedVerifyKeys.add(job.key);
      }
    }
    if (failedVerifyKeys.size === 0) return;
    await withStorageLock(async () => {
      const latestQueue = await storage.getQueue();
      const results = await storage.getResults(account);
      const selSet = await storage.getSelection(account);
      const now = Date.now();
      const updatedJobs = latestQueue.jobs.map((j) => {
        if (!failedVerifyKeys.has(j.key)) return j;
        results[j.key] = {
          status: "failed",
          error: "Repost v\u1EABn c\xF2n tr\xEAn TikTok sau khi x\xE1c minh m\xE1y ch\u1EE7.",
          processedAt: now
        };
        selSet.add(j.key);
        return {
          ...j,
          status: "failed",
          error: "Repost v\u1EABn c\xF2n tr\xEAn TikTok sau khi x\xE1c minh m\xE1y ch\u1EE7.",
          errorCode: "SERVER_VERIFY_STILL_PRESENT",
          processedAt: now
        };
      });
      await storage.setResults(account, results);
      await storage.setSelection(account, selSet);
      await storage.setQueue({ ...latestQueue, jobs: updatedJobs });
    });
    await storage.appendLog({
      level: "warn",
      message: `X\xE1c minh m\xE1y ch\u1EE7: ${failedVerifyKeys.size} video v\u1EABn c\xF2n tr\u1EA1ng th\xE1i Repost v\xE0 \u0111\xE3 \u0111\u01B0\u1EE3c \u0111\xE1nh d\u1EA5u Th\u1EA5t b\u1EA1i \u0111\u1EC3 th\u1EED l\u1EA1i.`,
      account
    });
  } catch {
  }
}
async function runQueueLoop(runToken) {
  if (isLoopRunning) return;
  isLoopRunning = true;
  const isInterrupted = () => queueStopRequested || queuePauseRequested || activeQueueRunToken !== runToken;
  let attemptsInGroup = 0;
  let groupTarget = randomBetween(35, 45);
  let activatedTabOnce = false;
  try {
    while (true) {
      if (isInterrupted()) {
        await settleUserInterrupt();
        break;
      }
      let queue = await storage.getQueue();
      if (queue.status === "pausing") {
        await settleUserInterrupt();
        await storage.appendLog({ level: "info", message: "\u0110\xE3 t\u1EA1m d\u1EEBng h\xE0ng \u0111\u1EE3i d\u1ECDn d\u1EB9p." });
        break;
      }
      if (queue.status !== "running") {
        break;
      }
      const pendingIdx = nextPendingIndex(queue);
      if (pendingIdx === -1) {
        const acc = await storage.getAccount();
        if (!isInterrupted() && queue.workerTabId && queue.account && acc?.secUid) {
          await verifyRemovedRepostsOnServer(queue.workerTabId, queue.account, acc.secUid);
        }
        if (isInterrupted()) {
          await settleUserInterrupt();
          break;
        }
        const now = Date.now();
        let completedSummary = null;
        await withStorageLock(async () => {
          const latest = await storage.getQueue();
          if (latest.status !== "running") return;
          const doneQueue = complete(latest, now);
          await storage.setQueue(doneQueue);
          queue = doneQueue;
          completedSummary = summarize(doneQueue);
        });
        if (completedSummary) {
          const s = completedSummary;
          const historyEntry = {
            runId: queue.runId || uid("run"),
            account: queue.account,
            startedAt: queue.startedAt,
            finishedAt: now,
            total: s.total,
            success: s.success,
            failed: s.failed,
            unverified: s.unverified,
            skipped: s.skipped,
            unavailable: s.unavailable,
            endStatus: "completed",
            reason: null
          };
          await storage.addHistory(historyEntry);
          await storage.appendLog({
            level: "success",
            message: `Ho\xE0n t\u1EA5t d\u1ECDn d\u1EB9p! Th\xE0nh c\xF4ng: ${s.success}, B\u1ECF qua (\u0111\xE3 x\xE1c minh): ${s.skipped}, Ch\u01B0a x\xE1c minh: ${s.unverified}, Th\u1EA5t b\u1EA1i: ${s.failed}, B\u1ECB \u1EA9n/x\xF3a: ${s.unavailable}.`,
            account: queue.account
          });
        }
        break;
      }
      let markedOk = false;
      await withStorageLock(async () => {
        const latest = await storage.getQueue();
        if (latest.status !== "running" || isInterrupted()) return;
        queue = markProcessing(latest, pendingIdx);
        await storage.setQueue(queue);
        markedOk = true;
      });
      if (!markedOk) {
        await settleUserInterrupt(pendingIdx);
        break;
      }
      const job = queue.jobs[pendingIdx];
      let workerTab = null;
      if (queue.workerTabId) {
        try {
          const existing = await chrome.tabs.get(queue.workerTabId);
          if (existing && existing.id !== void 0) workerTab = existing;
        } catch {
          workerTab = null;
        }
      }
      if (!workerTab || workerTab.id === void 0) {
        workerTab = await findTikTokTab();
      }
      if (!workerTab || workerTab.id === void 0) {
        if (isInterrupted()) {
          await settleUserInterrupt(pendingIdx);
          break;
        }
        workerTab = await ensureTikTokTab();
        if (workerTab.id !== void 0) {
          await waitForTabComplete(workerTab.id, 12e3);
        }
      }
      if (isInterrupted()) {
        await settleUserInterrupt(pendingIdx);
        break;
      }
      const tabId = workerTab.id;
      if (!activatedTabOnce) {
        activatedTabOnce = true;
        await chrome.tabs.update(tabId, { active: true }).catch(() => {
        });
      }
      if (queue.workerTabId !== tabId) {
        await withStorageLock(async () => {
          const latest = await storage.getQueue();
          if (latest.status === "running" && !isInterrupted()) {
            queue = { ...latest, workerTabId: tabId };
            await storage.setQueue(queue);
          }
        });
      }
      if (isInterrupted()) {
        await settleUserInterrupt(pendingIdx);
        break;
      }
      const initialPing = await pingTab(tabId);
      if (isInterrupted()) {
        await settleUserInterrupt(pendingIdx);
        break;
      }
      if (initialPing?.http403) {
        const msg = "Ph\xE1t hi\u1EC7n l\u1ED7i HTTP 403 (Access Denied) tr\xEAn TikTok. \u0110\xE3 d\u1EEBng ngay v\xE0 l\u01B0u ti\u1EBFn \u0111\u1ED9 \u0111\u1EC3 b\u1EA3o v\u1EC7 t\xE0i kho\u1EA3n.";
        await revertJobToPending(pendingIdx, "HTTP_403", msg);
        await storage.appendLog({
          level: "error",
          message: msg,
          videoId: job.videoId,
          action: job.action,
          account: queue.account
        });
        break;
      }
      if (initialPing?.captcha) {
        const msg = "Ph\xE1t hi\u1EC7n CAPTCHA tr\xEAn TikTok. Vui l\xF2ng ho\xE0n t\u1EA5t x\xE1c minh r\u1ED3i nh\u1EA5n Ti\u1EBFp t\u1EE5c.";
        await revertJobToPending(pendingIdx, "CAPTCHA", msg);
        await storage.appendLog({
          level: "warn",
          message: msg,
          videoId: job.videoId,
          action: job.action,
          account: queue.account
        });
        break;
      }
      const currentAcc = await checkAccount(tabId);
      if (isInterrupted()) {
        await settleUserInterrupt(pendingIdx);
        break;
      }
      if (currentAcc.username && queue.account && currentAcc.username.toLowerCase() !== queue.account.toLowerCase()) {
        const msg = `T\xE0i kho\u1EA3n TikTok \u0111\xE3 \u0111\u1ED5i t\u1EEB @${queue.account} sang @${currentAcc.username}. \u0110\xE3 t\u1EA1m d\u1EEBng an to\xE0n.`;
        await revertJobToPending(pendingIdx, "ACCOUNT_MISMATCH", msg);
        await storage.appendLog({
          level: "error",
          message: msg,
          videoId: job.videoId,
          action: job.action
        });
        break;
      }
      const cleanAccount = (queue.account || "").replace(/^@/, "");
      if (job.action === "remove_like" && cleanAccount) {
        const navRes = await navigateAndWaitForProfile(tabId, cleanAccount, 15e3, isInterrupted);
        if (navRes.aborted || isInterrupted()) {
          await settleUserInterrupt(pendingIdx);
          break;
        }
        if (navRes.http403) {
          const msg = "TikTok tr\u1EA3 v\u1EC1 HTTP 403 khi m\u1EDF trang c\xE1 nh\xE2n. \u0110\xE3 d\u1EEBng ngay v\xE0 l\u01B0u ti\u1EBFn \u0111\u1ED9.";
          await revertJobToPending(pendingIdx, "HTTP_403", msg);
          await storage.appendLog({ level: "error", message: msg, account: queue.account });
          break;
        }
        if (!navRes.ok) {
          const msg = `Kh\xF4ng th\u1EC3 t\u1EA3i trang c\xE1 nh\xE2n @${cleanAccount}. \u0110\xE3 t\u1EA1m d\u1EEBng v\xE0 l\u01B0u ti\u1EBFn \u0111\u1ED9.`;
          await revertJobToPending(pendingIdx, "PROFILE_LOAD_TIMEOUT", msg);
          await storage.appendLog({ level: "error", message: msg, account: queue.account });
          break;
        }
      }
      const readyPing = await pingTab(tabId);
      if (isInterrupted()) {
        await settleUserInterrupt(pendingIdx);
        break;
      }
      if (readyPing?.http403) {
        const msg = "Ph\xE1t hi\u1EC7n l\u1ED7i HTTP 403 tr\xEAn TikTok. \u0110\xE3 t\u1EA1m d\u1EEBng v\xE0 l\u01B0u ti\u1EBFn \u0111\u1ED9.";
        await revertJobToPending(pendingIdx, "HTTP_403", msg);
        await storage.appendLog({ level: "error", message: msg, account: queue.account });
        break;
      }
      let outcomeResult;
      if (!readyPing?.ok) {
        outcomeResult = {
          status: "failed",
          code: "PAGE_LOAD_TIMEOUT",
          message: "Kh\xF4ng th\u1EC3 k\u1EBFt n\u1ED1i v\u1EDBi tab TikTok \u0111\u1EC3 th\u1EF1c hi\u1EC7n thao t\xE1c."
        };
      } else {
        try {
          const actionResponse = await chrome.tabs.sendMessage(tabId, {
            type: "PERFORM",
            action: job.action,
            videoId: job.videoId,
            account: queue.account || "",
            url: job.url
          });
          outcomeResult = actionResponse || {
            status: "failed",
            code: "EMPTY_RESPONSE",
            message: "Kh\xF4ng nh\u1EADn \u0111\u01B0\u1EE3c ph\u1EA3n h\u1ED3i t\u1EEB trang TikTok."
          };
        } catch (err) {
          outcomeResult = {
            status: "failed",
            code: "COMMUNICATION_ERROR",
            message: err instanceof Error ? err.message : String(err)
          };
        }
      }
      if (outcomeResult.code === "USER_ABORTED") {
        await settleUserInterrupt(pendingIdx);
        break;
      }
      if (job.action === "remove_like" && (outcomeResult.code === "CARD_NOT_FOUND_ON_GRID" || outcomeResult.code === "MODAL_NOT_OPENED") && job.url && /\/(?:video|photo)\/\d+/.test(job.url)) {
        await storage.appendLog({
          level: "info",
          message: `[Like] Video ${job.videoId}: ${outcomeResult.message} \u0110ang m\u1EDF tr\u1EF1c ti\u1EBFp tr\xEAn c\xF9ng tab \u0111\u1EC3 ki\u1EC3m tra n\xFAt Tim...`,
          videoId: job.videoId,
          action: job.action,
          account: queue.account
        });
        const directNav = await navigateAndWaitForDirectVideo(
          tabId,
          job.url,
          job.videoId,
          15e3,
          isInterrupted
        );
        if (directNav.aborted || isInterrupted()) {
          await settleUserInterrupt(pendingIdx);
          break;
        }
        if (directNav.http403) {
          const msg = "TikTok tr\u1EA3 v\u1EC1 HTTP 403 khi m\u1EDF tr\u1EF1c ti\u1EBFp video. \u0110\xE3 d\u1EEBng ngay v\xE0 l\u01B0u ti\u1EBFn \u0111\u1ED9.";
          await revertJobToPending(pendingIdx, "HTTP_403", msg);
          await storage.appendLog({ level: "error", message: msg, videoId: job.videoId, action: job.action, account: queue.account });
          break;
        }
        if (directNav.captcha) {
          const msg = "Ph\xE1t hi\u1EC7n CAPTCHA khi m\u1EDF tr\u1EF1c ti\u1EBFp video. Vui l\xF2ng ho\xE0n t\u1EA5t x\xE1c minh r\u1ED3i nh\u1EA5n Ti\u1EBFp t\u1EE5c.";
          await revertJobToPending(pendingIdx, "CAPTCHA", msg);
          await storage.appendLog({ level: "warn", message: msg, videoId: job.videoId, action: job.action, account: queue.account });
          break;
        }
        if (directNav.ok) {
          try {
            const directRes = await chrome.tabs.sendMessage(tabId, {
              type: "PERFORM",
              action: job.action,
              videoId: job.videoId,
              account: queue.account || "",
              url: job.url,
              directVideoPage: true
            });
            if (directRes) {
              outcomeResult = directRes;
            }
          } catch (err) {
            outcomeResult = {
              status: "unverified",
              code: "DIRECT_VIDEO_COMM_ERROR",
              stage: "UNVERIFIED",
              message: `Kh\xF4ng th\u1EC3 \u0111\u1ECDc tr\u1EA1ng th\xE1i n\xFAt Tim tr\xEAn trang video (${err instanceof Error ? err.message : String(err)})`
            };
          }
        } else {
          outcomeResult = {
            status: "unverified",
            code: "DIRECT_VIDEO_LOAD_TIMEOUT",
            stage: "UNVERIFIED",
            message: "H\u1EBFt th\u1EDDi gian ch\u1EDD t\u1EA3i trang video tr\u1EF1c ti\u1EBFp \u2014 \u0111\xE1nh d\u1EA5u UNVERIFIED (kh\xF4ng t\u1EF1 SKIPPED)."
          };
        }
        if (outcomeResult.code === "USER_ABORTED") {
          await settleUserInterrupt(pendingIdx);
          break;
        }
      }
      const settings = await storage.getSettings();
      let halted = false;
      let interruptedAfterAction = false;
      await withStorageLock(async () => {
        const latestQueue = await storage.getQueue();
        const wasStopped = queueStopRequested || latestQueue.status === "stopped";
        const wasPaused = queuePauseRequested || latestQueue.status === "pausing" || latestQueue.status === "paused";
        let baseQueue = latestQueue;
        if (baseQueue.jobs[pendingIdx]?.status === "pending") {
          baseQueue = markProcessing(baseQueue, pendingIdx);
        }
        const outcome = applyResult(baseQueue, pendingIdx, outcomeResult, {
          retryLimit: settings.retryLimit,
          stopOnConsecutiveErrors: settings.stopOnConsecutiveErrors,
          now: Date.now()
        });
        halted = outcome.halted;
        let nextQueue = outcome.queue;
        if (wasStopped) {
          nextQueue = {
            ...nextQueue,
            status: "stopped",
            reasonCode: latestQueue.reasonCode || "STOPPED",
            reason: latestQueue.reason || "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng (ti\u1EBFn \u0111\u1ED9 \u0111\u01B0\u1EE3c gi\u1EEF nguy\xEAn)",
            finishedAt: latestQueue.finishedAt || Date.now()
          };
          interruptedAfterAction = true;
        } else if (wasPaused) {
          nextQueue = {
            ...settlePause(nextQueue),
            status: "paused",
            reasonCode: latestQueue.reasonCode || "USER_PAUSE",
            reason: latestQueue.reason || "\u0110\xE3 t\u1EA1m d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng."
          };
          interruptedAfterAction = true;
        }
        queue = nextQueue;
        await storage.setQueue(queue);
        if (queue.account) {
          const results = await storage.getResults(queue.account);
          results[job.key] = {
            status: outcomeResult.status,
            error: outcomeResult.status === "success" ? null : outcomeResult.message,
            processedAt: Date.now()
          };
          await storage.setResults(queue.account, results);
          if (outcomeResult.status === "success" || outcomeResult.status === "skipped") {
            const selSet = await storage.getSelection(queue.account);
            selSet.delete(job.key);
            await storage.setSelection(queue.account, selSet);
          }
        }
      });
      const logLvl = outcomeResult.status === "success" ? "success" : outcomeResult.status === "skipped" ? "info" : outcomeResult.status === "unavailable" || outcomeResult.status === "unverified" ? "warn" : "error";
      const stageSuffix = outcomeResult.trace?.length ? ` [${outcomeResult.trace.join(" \u2192 ")}]` : outcomeResult.stage ? ` [${outcomeResult.stage}]` : "";
      const statusDetail = outcomeResult.status === "skipped" ? `[SKIPPED | L\xFD do: ${outcomeResult.skipReason || outcomeResult.code}] ` : outcomeResult.status === "unverified" ? `[UNVERIFIED | ${outcomeResult.code}] ` : "";
      await storage.appendLog({
        level: logLvl,
        message: `[${job.action === "remove_repost" ? "Repost" : "Like"}] Video ${job.videoId}: ${statusDetail}${outcomeResult.message}${stageSuffix}`,
        videoId: job.videoId,
        action: job.action,
        account: queue.account
      });
      if (interruptedAfterAction) {
        break;
      }
      if (halted) {
        await storage.appendLog({
          level: "warn",
          message: `\u0110\xE3 t\u1EA1m d\u1EEBng h\xE0ng \u0111\u1EE3i an to\xE0n: ${queue.reason || "\u0110\u1EA1t ng\u01B0\u1EE1ng b\u1EA3o v\u1EC7 t\xE0i kho\u1EA3n"}`,
          account: queue.account
        });
        break;
      }
      const afterQueue = await storage.getQueue();
      if (isInterrupted() || afterQueue.status !== "running" || nextPendingIndex(afterQueue) === -1) {
        if (isInterrupted()) await settleUserInterrupt();
        continue;
      }
      attemptsInGroup += 1;
      if (attemptsInGroup >= groupTarget) {
        attemptsInGroup = 0;
        groupTarget = randomBetween(35, 45);
        await interruptibleSleep(randomBetween(4e3, 7e3), runToken);
      } else {
        const baseDelay = Math.max(1e3, settings.actionDelay * 1e3);
        await interruptibleSleep(baseDelay + randomBetween(150, 750), runToken);
      }
    }
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    await withStorageLock(async () => {
      const q = await storage.getQueue();
      if (q.status === "stopped" || queueStopRequested) return;
      await storage.setQueue({
        ...q,
        status: "paused",
        reasonCode: "UNHANDLED_RUNNER_ERROR",
        reason: errorMsg
      });
    });
    await storage.appendLog({ level: "error", message: `L\u1ED7i ti\u1EBFn tr\xECnh d\u1ECDn d\u1EB9p: ${errorMsg}` });
  } finally {
    isLoopRunning = false;
  }
}
async function runSingleTabScanAttempt(tabId, scanToken, params) {
  return new Promise((resolve) => {
    let resolved = false;
    let checkInterval = null;
    const finish = (payload) => {
      if (resolved) return;
      resolved = true;
      if (checkInterval) clearInterval(checkInterval);
      chrome.runtime.onMessage.removeListener(doneListener);
      resolve(payload);
    };
    if (scanStopRequested || activeScanRunToken !== scanToken) {
      finish({
        kind: params.kind,
        total: 0,
        code: "CANCELLED",
        message: "\u0110\xE3 d\u1EEBng qu\xE9t theo y\xEAu c\u1EA7u."
      });
      return;
    }
    const doneListener = (msg) => {
      if (msg && msg.type === "SCAN_DONE" && msg.kind === params.kind) {
        finish({
          kind: params.kind,
          total: typeof msg.total === "number" ? msg.total : 0,
          code: msg.code || "COMPLETED",
          message: msg.message || "",
          haltRun: Boolean(msg.haltRun)
        });
      }
    };
    chrome.runtime.onMessage.addListener(doneListener);
    checkInterval = setInterval(async () => {
      if (resolved) return;
      if (scanStopRequested || activeScanRunToken !== scanToken) {
        finish({
          kind: params.kind,
          total: 0,
          code: "CANCELLED",
          message: "\u0110\xE3 d\u1EEBng qu\xE9t theo y\xEAu c\u1EA7u."
        });
        return;
      }
      const s = await storage.getScan();
      if (s.status !== "scanning") {
        finish({
          kind: params.kind,
          total: 0,
          code: "CANCELLED",
          message: "\u0110\xE3 d\u1EEBng qu\xE9t theo y\xEAu c\u1EA7u."
        });
        return;
      }
      try {
        const t = await chrome.tabs.get(tabId);
        if (!t) throw new Error("Tab closed");
      } catch {
        finish({
          kind: params.kind,
          total: 0,
          code: "TAB_CLOSED",
          message: "Tab TikTok \u0111\xE3 b\u1ECB \u0111\xF3ng trong khi qu\xE9t.",
          haltRun: true
        });
      }
    }, 250);
    chrome.tabs.sendMessage(tabId, {
      type: "START_SCAN_TAB",
      kind: params.kind,
      username: params.username,
      secUid: params.secUid,
      skipApi: params.skipApi,
      limit: params.limit,
      knownIds: params.knownIds
    }).catch((err) => {
      finish({
        kind: params.kind,
        total: 0,
        code: "COMMUNICATION_ERROR",
        message: err instanceof Error ? err.message : String(err)
      });
    });
  });
}
async function startScanFlow(kinds, scanToken) {
  const isScanStopped = () => scanStopRequested || activeScanRunToken !== scanToken;
  const curScan = await storage.getScan();
  if (curScan.status === "scanning") return;
  const curQueue = await storage.getQueue();
  if (isActive(curQueue)) {
    await storage.setScan({
      status: "error",
      account: curQueue.account,
      kinds,
      currentKind: null,
      found: 0,
      newFound: 0,
      message: "\u0110ang ch\u1EA1y d\u1ECDn d\u1EB9p video. Vui l\xF2ng t\u1EA1m d\u1EEBng ho\u1EB7c \u0111\u1EE3i ho\xE0n t\u1EA5t tr\u01B0\u1EDBc khi qu\xE9t m\u1EDBi.",
      code: "QUEUE_ACTIVE",
      startedAt: Date.now(),
      finishedAt: Date.now()
    });
    return;
  }
  const tab = await ensureTikTokTab();
  if (tab.id === void 0 || isScanStopped()) return;
  activeScanTabId = tab.id;
  await waitForTabComplete(tab.id, 12e3);
  if (isScanStopped()) return;
  const initialPing = await pingTab(tab.id);
  if (isScanStopped()) return;
  if (initialPing?.http403) {
    await storage.setScan({
      status: "error",
      account: null,
      kinds,
      currentKind: null,
      found: 0,
      newFound: 0,
      message: "Trang TikTok hi\u1EC7n \u0111ang b\xE1o l\u1ED7i HTTP 403 (Access Denied). Vui l\xF2ng t\u1EA3i l\u1EA1i trang ho\u1EB7c \u0111\u1EE3i v\xE0i ph\xFAt tr\u01B0\u1EDBc khi qu\xE9t.",
      code: "HTTP_403",
      startedAt: Date.now(),
      finishedAt: Date.now()
    });
    return;
  }
  let acc = await checkAccount(tab.id);
  if (!acc.loggedIn || !acc.username) {
    for (let i = 0; i < 6 && !isScanStopped(); i++) {
      await sleep(500);
      acc = await checkAccount(tab.id);
      if (acc.loggedIn && acc.username) break;
    }
  }
  if (isScanStopped()) return;
  if (!acc.loggedIn || !acc.username) {
    await storage.setScan({
      status: "error",
      account: null,
      kinds,
      currentKind: null,
      found: 0,
      newFound: 0,
      message: "Vui l\xF2ng \u0111\u0103ng nh\u1EADp t\xE0i kho\u1EA3n TikTok tr\xEAn tr\xECnh duy\u1EC7t tr\u01B0\u1EDBc khi qu\xE9t.",
      code: "NOT_LOGGED_IN",
      startedAt: Date.now(),
      finishedAt: Date.now()
    });
    return;
  }
  const cleanUsername = acc.username.replace(/^@/, "");
  const settings = await storage.getSettings();
  const kindsSet = new Set(kinds);
  let preservedCount = 0;
  let startedScanOk = false;
  await withStorageLock(async () => {
    if (isScanStopped()) return;
    const existingVideos = await storage.getVideos(cleanUsername);
    const preservedVideos = existingVideos.filter((v) => !kindsSet.has(v.kind));
    preservedCount = preservedVideos.length;
    await storage.setVideos(cleanUsername, preservedVideos);
    const existingSelection = await storage.getSelection(cleanUsername);
    const updatedSelection = new Set(
      Array.from(existingSelection).filter((key) => {
        const k = key.split(":")[0];
        return !kindsSet.has(k);
      })
    );
    await storage.setSelection(cleanUsername, updatedSelection);
    const existingResults = await storage.getResults(cleanUsername);
    const updatedResults = {};
    for (const [k, rec] of Object.entries(existingResults)) {
      const kindPrefix = k.split(":")[0];
      if (!kindsSet.has(kindPrefix)) {
        updatedResults[k] = rec;
      }
    }
    await storage.setResults(cleanUsername, updatedResults);
    const q = await storage.getQueue();
    if (!isActive(q) && kinds.length === 2) {
      await storage.setQueue(emptyQueue());
    }
    await storage.setScan({
      status: "scanning",
      account: cleanUsername,
      kinds,
      currentKind: kinds[0] || null,
      found: preservedCount,
      newFound: 0,
      message: `\u0110ang k\u1EBFt n\u1ED1i phi\xEAn TikTok @${cleanUsername}...`,
      code: null,
      startedAt: Date.now(),
      finishedAt: null
    });
    startedScanOk = true;
  });
  if (!startedScanOk || isScanStopped()) return;
  await storage.appendLog({
    level: "info",
    message: `B\u1EAFt \u0111\u1EA7u qu\xE9t ${kinds.join(" & ")} cho @${cleanUsername}`,
    account: cleanUsername
  });
  for (const kind of kinds) {
    if (isScanStopped()) break;
    const currentScan = await storage.getScan();
    if (currentScan.status !== "scanning") break;
    const kindLabel = kind === "repost" ? "\u0110\u0103ng l\u1EA1i (Reposts)" : "\u0110\xE3 th\xEDch (Likes)";
    await withStorageLock(async () => {
      if (isScanStopped()) return;
      const latest = await storage.getScan();
      if (latest.status !== "scanning") return;
      await storage.setScan({
        ...latest,
        currentKind: kind,
        message: `\u0110ang qu\xE9t danh s\xE1ch ${kindLabel}...`
      });
    });
    const videosNow = await storage.getVideos(cleanUsername);
    const knownIds = videosNow.filter((v) => v.kind === kind).map((v) => v.videoId);
    await pingTab(tab.id);
    if (isScanStopped()) break;
    let donePayload = await runSingleTabScanAttempt(tab.id, scanToken, {
      kind,
      username: cleanUsername,
      secUid: acc.secUid,
      skipApi: false,
      limit: settings.scanLimit,
      knownIds
    });
    if (isScanStopped() || donePayload.code === "CANCELLED") {
      break;
    }
    if (donePayload.code === "NAVIGATING_TO_PROFILE") {
      const sCheck = await storage.getScan();
      if (isScanStopped() || sCheck.status !== "scanning") break;
      await withStorageLock(async () => {
        if (isScanStopped()) return;
        const latest = await storage.getScan();
        if (latest.status !== "scanning") return;
        await storage.setScan({
          ...latest,
          message: `\u0110ang m\u1EDF trang c\xE1 nh\xE2n @${cleanUsername} \u0111\u1EC3 ki\u1EC3m tra ${kindLabel}...`
        });
      });
      const navRes = await navigateAndWaitForProfile(tab.id, cleanUsername, 15e3, isScanStopped);
      if (navRes.aborted || isScanStopped()) {
        break;
      }
      if (navRes.http403) {
        donePayload = {
          kind,
          total: 0,
          code: "HTTP_403",
          message: "TikTok tr\u1EA3 v\u1EC1 HTTP 403 khi m\u1EDF trang c\xE1 nh\xE2n. \u0110\xE3 d\u1EEBng an to\xE0n.",
          haltRun: true
        };
      } else if (!navRes.ok) {
        donePayload = {
          kind,
          total: 0,
          code: "PAGE_LOAD_TIMEOUT",
          message: `Kh\xF4ng th\u1EC3 t\u1EA3i trang c\xE1 nh\xE2n @${cleanUsername}.`,
          haltRun: true
        };
      } else {
        const postNavScan = await storage.getScan();
        if (isScanStopped() || postNavScan.status !== "scanning") break;
        const refreshedVideos = await storage.getVideos(cleanUsername);
        const refreshedKnownIds = refreshedVideos.filter((v) => v.kind === kind).map((v) => v.videoId);
        donePayload = await runSingleTabScanAttempt(tab.id, scanToken, {
          kind,
          username: cleanUsername,
          secUid: acc.secUid,
          skipApi: true,
          limit: settings.scanLimit,
          knownIds: refreshedKnownIds
        });
      }
    }
    if (isScanStopped() || donePayload.code === "CANCELLED") {
      break;
    }
    if (donePayload.haltRun || HALT_CODES.has(donePayload.code)) {
      const videosAfter = await storage.getVideos(cleanUsername);
      await withStorageLock(async () => {
        if (isScanStopped()) return;
        await storage.setScan({
          status: "error",
          account: cleanUsername,
          kinds,
          currentKind: kind,
          found: videosAfter.length,
          newFound: videosAfter.length - preservedCount,
          message: donePayload.message || `Qu\xE9t t\u1EA1m d\u1EEBng do m\xE3 b\u1EA3o v\u1EC7 (${donePayload.code}).`,
          code: donePayload.code,
          startedAt: curScan.startedAt || Date.now(),
          finishedAt: Date.now()
        });
      });
      await storage.appendLog({
        level: "error",
        message: `Qu\xE9t d\u1EEBng an to\xE0n (${donePayload.code}): ${donePayload.message}`,
        account: cleanUsername
      });
      return;
    }
  }
  if (isScanStopped()) {
    return;
  }
  await withStorageLock(async () => {
    if (isScanStopped()) return;
    const finalScan = await storage.getScan();
    if (finalScan.status !== "scanning") return;
    const finalVideos = await storage.getVideos(cleanUsername);
    const repostCount = finalVideos.filter((v) => v.kind === "repost").length;
    const likeCount = finalVideos.filter((v) => v.kind === "like").length;
    let detailMsg = `Qu\xE9t th\xE0nh c\xF4ng! \u0110\xE3 t\xECm th\u1EA5y ${finalVideos.length} video.`;
    if (kinds.length > 1) {
      detailMsg = `Qu\xE9t th\xE0nh c\xF4ng! (${repostCount} Reposts, ${likeCount} Likes)`;
    } else if (kinds[0] === "repost") {
      detailMsg = `Qu\xE9t th\xE0nh c\xF4ng! \u0110\xE3 t\xECm th\u1EA5y ${repostCount} video Repost.`;
    } else if (kinds[0] === "like") {
      detailMsg = `Qu\xE9t th\xE0nh c\xF4ng! \u0110\xE3 t\xECm th\u1EA5y ${likeCount} video \u0110\xE3 th\xEDch.`;
    }
    await storage.setScan({
      ...finalScan,
      status: "done",
      currentKind: null,
      found: finalVideos.length,
      message: detailMsg,
      finishedAt: Date.now()
    });
    await storage.appendLog({
      level: "success",
      message: `Ho\xE0n t\u1EA5t: ${detailMsg} cho @${cleanUsername}`,
      account: cleanUsername
    });
  });
}
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    const handle = async () => {
      switch (message.type) {
        case "GET_ACCOUNT": {
          const acc = await checkAccount();
          return { ok: true, data: acc };
        }
        case "GET_PAGE_SESSION": {
          const tabId = sender.tab?.id;
          if (tabId === void 0) {
            return { loggedIn: false, username: null, secUid: null, uid: null, http403: false };
          }
          const session = await getPageSessionFromMainWorld(tabId);
          return session || { loggedIn: false, username: null, secUid: null, uid: null, http403: false };
        }
        case "TIKTOK_API_FETCH": {
          const tabId = sender.tab?.id;
          if (tabId === void 0) {
            return { ok: false, status: 0, data: null, networkError: "Missing sender tabId" };
          }
          return executeMainWorldFetch(tabId, {
            pathAndQuery: String(message.pathAndQuery || ""),
            method: message.method === "POST" ? "POST" : "GET",
            body: typeof message.body === "string" ? message.body : void 0,
            headers: message.headers,
            timeoutMs: typeof message.timeoutMs === "number" ? message.timeoutMs : 2e4
          });
        }
        case "CONTENT_READY": {
          if (sender.tab?.id !== void 0) {
            checkAccount(sender.tab.id).catch(() => {
            });
          }
          return { ok: true };
        }
        case "OPEN_TIKTOK": {
          await ensureTikTokTab();
          return { ok: true };
        }
        case "OPEN_DASHBOARD": {
          const url = chrome.runtime.getURL("dashboard.html");
          const tabs = await chrome.tabs.query({ url });
          if (tabs.length > 0 && tabs[0].id !== void 0) {
            await chrome.tabs.update(tabs[0].id, { active: true });
            if (tabs[0].windowId) await chrome.windows.update(tabs[0].windowId, { focused: true });
          } else {
            await chrome.tabs.create({ url, active: true });
          }
          return { ok: true };
        }
        case "START_SCAN": {
          scanStopRequested = false;
          const scanToken = ++activeScanRunToken;
          startScanFlow(message.kinds, scanToken).catch(() => {
          });
          return { ok: true };
        }
        case "STOP_SCAN": {
          scanStopRequested = true;
          activeScanRunToken += 1;
          broadcastToTikTokTabs({ type: "SCAN_STOP" }, activeScanTabId).catch(() => {
          });
          await withStorageLock(async () => {
            const s = await storage.getScan();
            await storage.setScan({
              ...s,
              status: "stopped",
              currentKind: null,
              message: "\u0110\xE3 d\u1EEBng qu\xE9t; c\xE1c video thu th\u1EADp \u0111\u01B0\u1EE3c \u0111\xE3 \u0111\u01B0\u1EE3c gi\u1EEF l\u1EA1i.",
              finishedAt: Date.now()
            });
          });
          await storage.appendLog({
            level: "warn",
            message: "\u0110\xE3 d\u1EEBng qu\xE9t theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng."
          });
          return { ok: true };
        }
        case "START_CLEANUP": {
          const curScan = await storage.getScan();
          if (curScan.status === "scanning") {
            return { ok: false, error: "Vui l\xF2ng d\u1EEBng ho\u1EB7c \u0111\u1EE3i qu\xE1 tr\xECnh qu\xE9t ho\xE0n t\u1EA5t tr\u01B0\u1EDBc khi d\u1ECDn d\u1EB9p." };
          }
          const curQueue = await storage.getQueue();
          if (isActive(curQueue)) {
            return { ok: false, error: "H\xE0ng \u0111\u1EE3i d\u1ECDn d\u1EB9p \u0111ang ch\u1EA1y." };
          }
          const acc = await checkAccount();
          if (!acc || !acc.loggedIn || !acc.username) {
            return { ok: false, error: "Vui l\xF2ng \u0111\u0103ng nh\u1EADp TikTok tr\u01B0\u1EDBc khi d\u1ECDn d\u1EB9p." };
          }
          const username = acc.username;
          let q = emptyQueue();
          await withStorageLock(async () => {
            const allVideos = await storage.getVideos(username);
            const existingResults = await storage.getResults(username);
            const selKeys = new Set(message.keys);
            const eligibleVideos = allVideos.filter(
              (v) => selKeys.has(v.key) && isEligible(v, existingResults)
            );
            let modifiedResults = false;
            for (const v of eligibleVideos) {
              if (existingResults[v.key]?.status === "failed") {
                delete existingResults[v.key];
                modifiedResults = true;
              }
            }
            if (modifiedResults) {
              await storage.setResults(username, existingResults);
            }
            const settings = await storage.getSettings();
            const runId = uid("run_");
            q = createQueue(eligibleVideos, username, settings.maxItemsPerRun, runId, Date.now());
            await storage.setQueue(q);
          });
          if (q.jobs.length === 0) {
            await storage.setQueue(emptyQueue());
            return { ok: false, error: "Kh\xF4ng c\xF3 video h\u1EE3p l\u1EC7 n\xE0o c\u1EA7n d\u1ECDn d\u1EB9p trong l\u1EF1a ch\u1ECDn." };
          }
          queueStopRequested = false;
          queuePauseRequested = false;
          const runToken = ++activeQueueRunToken;
          await storage.appendLog({
            level: "info",
            message: `B\u1EAFt \u0111\u1EA7u d\u1ECDn d\u1EB9p tu\u1EA7n t\u1EF1 ${q.jobs.length} video cho @${username}`,
            account: username
          });
          runQueueLoop(runToken).catch(() => {
          });
          return { ok: true, data: q };
        }
        case "PAUSE": {
          queuePauseRequested = true;
          let updatedQueue = emptyQueue();
          await withStorageLock(async () => {
            let q = await storage.getQueue();
            broadcastToTikTokTabs({ type: "ACTION_STOP" }, q.workerTabId).catch(() => {
            });
            q = requestPause(q);
            if (!isLoopRunning && q.status === "pausing") {
              q = settlePause(q);
            }
            updatedQueue = q;
            await storage.setQueue(q);
          });
          await storage.appendLog({ level: "info", message: "\u0110\xE3 y\xEAu c\u1EA7u t\u1EA1m d\u1EEBng d\u1ECDn d\u1EB9p." });
          return { ok: true, data: updatedQueue };
        }
        case "RESUME": {
          const curScan = await storage.getScan();
          if (curScan.status === "scanning") {
            return { ok: false, error: "\u0110ang qu\xE9t d\u1EEF li\u1EC7u, ch\u01B0a th\u1EC3 ti\u1EBFp t\u1EE5c d\u1ECDn d\u1EB9p." };
          }
          let resumedQueue = null;
          await withStorageLock(async () => {
            const q = await storage.getQueue();
            if (canResume(q)) {
              resumedQueue = resume(q);
              await storage.setQueue(resumedQueue);
            }
          });
          if (resumedQueue) {
            queueStopRequested = false;
            queuePauseRequested = false;
            const runToken = ++activeQueueRunToken;
            await storage.appendLog({ level: "info", message: "Ti\u1EBFp t\u1EE5c h\xE0ng \u0111\u1EE3i d\u1ECDn d\u1EB9p t\u1EEB ti\u1EBFn \u0111\u1ED9 \u0111\xE3 l\u01B0u." });
            runQueueLoop(runToken).catch(() => {
            });
            return { ok: true, data: resumedQueue };
          }
          return { ok: false, error: "Kh\xF4ng c\xF3 h\xE0ng \u0111\u1EE3i t\u1EA1m d\u1EEBng n\xE0o \u0111\u1EC3 ti\u1EBFp t\u1EE5c." };
        }
        case "STOP": {
          queueStopRequested = true;
          queuePauseRequested = false;
          activeQueueRunToken += 1;
          let stoppedQueue = emptyQueue();
          await withStorageLock(async () => {
            let q = await storage.getQueue();
            broadcastToTikTokTabs({ type: "ACTION_STOP" }, q.workerTabId).catch(() => {
            });
            q = stop(q, Date.now(), "\u0110\xE3 d\u1EEBng theo y\xEAu c\u1EA7u ng\u01B0\u1EDDi d\xF9ng (ti\u1EBFn \u0111\u1ED9 \u0111\u01B0\u1EE3c gi\u1EEF nguy\xEAn)");
            stoppedQueue = q;
            await storage.setQueue(q);
          });
          await storage.appendLog({ level: "warn", message: "\u0110\xE3 d\u1EEBng d\u1ECDn d\u1EB9p; ti\u1EBFn \u0111\u1ED9 \u0111\xE3 l\u01B0u \u0111\u1EC3 c\xF3 th\u1EC3 ti\u1EBFp t\u1EE5c." });
          return { ok: true, data: stoppedQueue };
        }
        case "RESET_PROGRESS": {
          const q = await storage.getQueue();
          if (isActive(q)) {
            return { ok: false, error: "Kh\xF4ng th\u1EC3 \u0111\u1EB7t l\u1EA1i khi h\xE0ng \u0111\u1EE3i \u0111ang ch\u1EA1y." };
          }
          await withStorageLock(async () => {
            await storage.setQueue(emptyQueue());
          });
          return { ok: true };
        }
        case "RESET_SESSION": {
          scanStopRequested = true;
          activeScanRunToken += 1;
          queueStopRequested = true;
          queuePauseRequested = false;
          activeQueueRunToken += 1;
          broadcastToTikTokTabs({ type: "SCAN_STOP" }, activeScanTabId).catch(() => {
          });
          broadcastToTikTokTabs({ type: "ACTION_STOP" }).catch(() => {
          });
          await withStorageLock(async () => {
            const acc = await storage.getAccount();
            if (acc?.username) {
              await storage.setVideos(acc.username, []);
              await storage.setSelection(acc.username, /* @__PURE__ */ new Set());
              await storage.setResults(acc.username, {});
            }
            await storage.setQueue(emptyQueue());
            await storage.setScan(emptyScan());
          });
          await storage.appendLog({
            level: "info",
            message: "\u0110\xE3 \u0111\u1EB7t l\u1EA1i to\xE0n b\u1ED9 danh s\xE1ch v\xE0 th\u1ED1ng k\xEA v\u1EC1 0."
          });
          return { ok: true };
        }
        case "CLEAR_CACHE": {
          scanStopRequested = true;
          activeScanRunToken += 1;
          queueStopRequested = true;
          queuePauseRequested = false;
          activeQueueRunToken += 1;
          broadcastToTikTokTabs({ type: "SCAN_STOP" }, activeScanTabId).catch(() => {
          });
          broadcastToTikTokTabs({ type: "ACTION_STOP" }).catch(() => {
          });
          await withStorageLock(async () => {
            await storage.clearAll();
          });
          return { ok: true };
        }
        case "SCAN_BATCH": {
          return withStorageLock(async () => {
            if (scanStopRequested) return { ok: true };
            const { kind, items } = message;
            const scan = await storage.getScan();
            if (scan.status !== "scanning") return { ok: true };
            const username = scan.account || (await storage.getAccount())?.username;
            if (!username) return { ok: false };
            const currentVideos = await storage.getVideos(username);
            const videoMap = /* @__PURE__ */ new Map();
            let nextScanIndex = 0;
            for (const v of currentVideos) {
              videoMap.set(v.key, v);
              if (v.scanIndex >= nextScanIndex) {
                nextScanIndex = v.scanIndex + 1;
              }
            }
            const now = Date.now();
            let addedCount = 0;
            for (const item of items) {
              const key = videoKey(kind, item.videoId);
              const existing = videoMap.get(key);
              if (!existing) {
                const scannedVideo = {
                  ...item,
                  key,
                  scanIndex: nextScanIndex++,
                  scannedAt: now
                };
                videoMap.set(key, scannedVideo);
                addedCount++;
              } else {
                let modified = false;
                if (!existing.thumbnail && item.thumbnail) {
                  existing.thumbnail = item.thumbnail;
                  modified = true;
                }
                if (!existing.description && item.description) {
                  existing.description = item.description;
                  modified = true;
                }
                if (existing.views === null && item.views !== null) {
                  existing.views = item.views;
                  existing.viewsText = item.viewsText;
                  modified = true;
                }
                if (!existing.scanPage && item.scanPage) {
                  existing.scanPage = item.scanPage;
                  modified = true;
                }
                if (modified) {
                  videoMap.set(key, { ...existing });
                }
              }
            }
            if (scanStopRequested) return { ok: true };
            const latestScan = await storage.getScan();
            if (latestScan.status !== "scanning") return { ok: true };
            const updatedVideos = Array.from(videoMap.values());
            await storage.setVideos(username, updatedVideos);
            await storage.setScan({
              ...latestScan,
              found: updatedVideos.length,
              newFound: (latestScan.newFound || 0) + addedCount
            });
            return { ok: true };
          });
        }
        case "SCAN_PROGRESS": {
          return withStorageLock(async () => {
            if (scanStopRequested) return { ok: true };
            const scan = await storage.getScan();
            if (scan.status !== "scanning") return { ok: true };
            const username = scan.account;
            const totalVideos = username ? (await storage.getVideos(username)).length : message.found;
            if (scanStopRequested) return { ok: true };
            const latestScan = await storage.getScan();
            if (latestScan.status !== "scanning") return { ok: true };
            await storage.setScan({
              ...latestScan,
              found: Math.max(totalVideos, message.found || 0),
              message: message.message || latestScan.message
            });
            return { ok: true };
          });
        }
        case "SCAN_DONE": {
          return { ok: true };
        }
        default:
          return { ok: false, error: "Unknown message type" };
      }
    };
    handle().then(sendResponse);
    return true;
  }
);
